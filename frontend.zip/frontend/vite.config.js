import { defineConfig } from 'vite'
import tailwindcss from '@tailwindcss/vite'
import { tanstackStart } from '@tanstack/react-start/plugin/vite'
import viteReact from '@vitejs/plugin-react'

// https://vite.dev/config/
export default defineConfig({
  server: {
    port: 3000,
  },
  plugins: [
    tailwindcss(),
    tanstackStart({
      // The app is localStorage/session driven, so it runs as a client-side SPA
      // while still using Start's file-based routes and build pipeline.
      spa: { enabled: true },
    }),
    // React's plugin must come after Start's plugin.
    viteReact(),
  ],
})
