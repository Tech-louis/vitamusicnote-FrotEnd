import { useMemo } from "react";

import AppLink from "./AppLink.jsx";
import MaterialIcon from "./MaterialIcon.jsx";
import { normalizeQuery, searchCatalog } from "../../services/catalogSearch.js";

export default function SearchBar({ search = "", setSearch, t, onSearch }) {
  const query = normalizeQuery(search);
  const results = useMemo(
    () => searchCatalog(query, { songLimit: 6, composerLimit: 2 }),
    [query]
  );
  const total = results.songs.length + results.composers.length;
  const categoryDictionary = t("category");

  function categoryLabel(song) {
    return (categoryDictionary && typeof categoryDictionary === "object"
      ? categoryDictionary[song.category]
      : null) || song.category;
  }

  function submit(event) {
    event.preventDefault();
    onSearch?.(query);
  }

  return (
    <div className="vmn-live-search-wrap">
      <form className="search-bar" role="search" onSubmit={submit}>
        <MaterialIcon name="search" size={22} />
        <input
          type="search"
          placeholder={t("searchPlaceholder")}
          value={search}
          onChange={(event) => setSearch?.(event.target.value)}
          aria-label={t("searchPlaceholder")}
          aria-expanded={Boolean(query)}
          aria-controls="vmn-live-search-results"
        />
        <button type="submit" className="vmn-search-submit" disabled={!query}>
          {t("search")}
        </button>
        {search && (
          <button
            type="button"
            className="search-clear"
            onClick={() => setSearch?.("")}
            aria-label={t("clearSearch", "Clear search")}
          >
            <MaterialIcon name="close" size={18} />
          </button>
        )}
      </form>

      {query && (
        <div className="vmn-live-search-results" id="vmn-live-search-results" role="region" aria-label={t("search")}>
          <div className="vmn-live-search-heading">
            <span>{t("suggestions")}</span>
            <small>
              {total} {total === 1 ? t("song") : t("songs")}
            </small>
          </div>

          {results.songs.map((song) => (
            <button
              type="button"
              className="vmn-search-result animate__animated animate__fadeInUp"
              key={`song-${song.id}`}
              onClick={() => onSearch?.(song.title)}
            >
              <div className="vmn-search-result-icon"><MaterialIcon name="music_note" size={20} /></div>
              <div className="vmn-search-result-info">
                <strong>{song.title}</strong>
                <span>{song.composer} · {song.voices}</span>
                <small>{categoryLabel(song)}</small>
              </div>
            </button>
          ))}

          {results.composers.map((composer) => (
            <article className="vmn-search-result" key={`composer-${composer.id}`}>
              <div className="vmn-search-result-icon"><MaterialIcon name="person" size={20} /></div>
              <div className="vmn-search-result-info">
                <strong>{composer.name}</strong>
                <span>{composer.focus}</span>
                <small>{composer.location}</small>
              </div>
              <AppLink className="vmn-search-result-action" href="/composers">
                {t("composers")} <MaterialIcon name="arrow_forward" size={18} />
              </AppLink>
            </article>
          ))}

          {total === 0 && (
            <div className="vmn-search-empty">{t("noResults")}</div>
          )}

          <button type="button" className="vmn-search-view-all" onClick={() => onSearch?.(query)}>
            {t("viewAll")} “{query}” <MaterialIcon name="arrow_forward" size={18} />
          </button>
        </div>
      )}
    </div>
  );
}
