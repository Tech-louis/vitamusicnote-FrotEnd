import { useEffect, useRef, useState } from "react";
import { libraryService } from "../../services/library.js";
import { getPreviewUrl } from "../../services/previewUrl.js";
import MaterialIcon from "./MaterialIcon.jsx";

function SheetPreview({ song, previewUrl, onPlayStateChange, activePreviewId }) {
  const audioRef = useRef(null);
  const [playing, setPlaying] = useState(false);
  const [currentTime, setCurrentTime] = useState(0);
  const [duration, setDuration] = useState(0);
  const [audioError, setAudioError] = useState(false);

  useEffect(() => {
    const audio = audioRef.current;
    if (!audio) return undefined;
    const updateTime = () => setCurrentTime(audio.currentTime || 0);
    const updateDuration = () => setDuration(Number.isFinite(audio.duration) ? audio.duration : 0);
    const handleEnded = () => {
      setPlaying(false);
      setCurrentTime(0);
      onPlayStateChange?.(null);
    };
    const handleError = () => setAudioError(true);
    const handlePause = () => setPlaying(false);
    audio.addEventListener("timeupdate", updateTime);
    audio.addEventListener("loadedmetadata", updateDuration);
    audio.addEventListener("ended", handleEnded);
    audio.addEventListener("error", handleError);
    audio.addEventListener("pause", handlePause);
    return () => {
      audio.removeEventListener("timeupdate", updateTime);
      audio.removeEventListener("loadedmetadata", updateDuration);
      audio.removeEventListener("ended", handleEnded);
      audio.removeEventListener("error", handleError);
      audio.removeEventListener("pause", handlePause);
    };
  }, [onPlayStateChange]);

  // Parent sends the id of the one card allowed to play.
  useEffect(() => {
    if (activePreviewId !== null && activePreviewId !== song.id && playing) {
      // The "pause" event listener updates state; no synchronous setState in an effect.
      audioRef.current?.pause();
    }
  }, [activePreviewId, song.id, playing]);

  async function togglePlayback() {
    const audio = audioRef.current;
    if (!audio || !previewUrl) return;
    if (playing) {
      audio.pause();
      setPlaying(false);
      onPlayStateChange?.(null);
      return;
    }
    onPlayStateChange?.(song.id);
    try {
      // Preview is limited to 45 seconds; the original audio file is not modified.
      if (audio.currentTime >= 45 || (duration && audio.currentTime >= duration)) {
        audio.currentTime = 0;
      }
      await audio.play();
      setPlaying(true);
    } catch {
      setAudioError(true);
      setPlaying(false);
      onPlayStateChange?.(null);
    }
  }

  function limitPreview() {
    const audio = audioRef.current;
    if (audio && audio.currentTime >= 45) {
      audio.pause();
      audio.currentTime = 0;
      setCurrentTime(0);
      setPlaying(false);
      onPlayStateChange?.(null);
    }
  }

  const shownDuration = Math.min(duration || 45, 45);
  const progress = shownDuration ? Math.min(100, (currentTime / shownDuration) * 100) : 0;

  return (
    <div className="sheet-preview" aria-label={`Music preview for ${song.title}`}>
      <div className="sheet-staff">
        <span>𝄞</span>
        <span>♪ ♫ ♩ ♪ ♬</span>
        <span>♫ ♩ ♪ ♫</span>
      </div>
      <div className="preview-controls">
        <button
          type="button"
          className="preview-play-button"
          onClick={togglePlayback}
          disabled={!previewUrl || audioError}
          aria-label={playing ? `Pause ${song.title}` : `Play preview of ${song.title}`}
          title={!previewUrl ? "Audio preview is not available for this song" : audioError ? "Unable to load audio preview" : playing ? "Pause preview" : "Play preview"}
        >
          <MaterialIcon name={playing ? "pause" : "play_arrow"} size={18} />
        </button>
        <MaterialIcon name="headphones" size={16} className="preview-headphones" />
      </div>
      {previewUrl && (
        <>
          <audio
            ref={audioRef}
            src={previewUrl}
            preload="none"
            data-song-id={String(song.id)}
            onTimeUpdate={limitPreview}
          />
          <div className="preview-progress" aria-label="Preview progress">
            <span style={{ width: `${progress}%` }} />
          </div>
          <span className="preview-time">{Math.floor(currentTime)}s / 45s</span>
        </>
      )}
    </div>
  );
}

export default function MusicCard({ song, t, onPreviewPlay, activePreviewId }) {
  const previewUrl = getPreviewUrl(song);
  const [isFavorite, setIsFavorite] = useState(() => libraryService.isFavorite(song.id));

  useEffect(() => libraryService.subscribe(() => {
    setIsFavorite(libraryService.isFavorite(song.id));
  }), [song.id]);

  return (
    <article className="music-card animate__animated animate__fadeInUp">
      <SheetPreview song={song} previewUrl={previewUrl} onPlayStateChange={onPreviewPlay} activePreviewId={activePreviewId} />

      <div className="music-info">
        <h3>{song.title}</h3>
        <p>{song.voices} <span>•</span> {t("category")[song.category] || song.category}</p>
        <small>{song.composer}</small>
        <div className="rating">
          <MaterialIcon name="star" size={17} className="music-card-star" />
          <span>{song.rating} ({song.reviews})</span>
        </div>
      </div>

      <div className="music-actions">
        {song.download_url && (
          <button className="music-action-button" type="button" onClick={() => song.download_url && window.open(song.download_url, "_blank", "noopener,noreferrer")} disabled={!song.download_url}>
            <MaterialIcon name="download" size={18} />
            {t("download")}
          </button>
        )}
        <button
          className={`music-action-button favorite-button ${isFavorite ? "is-active" : ""}`}
          type="button"
          onClick={() => libraryService.toggleFavorite(song.id)}
          aria-pressed={isFavorite}
          aria-label={isFavorite ? `${t("remove")} ${song.title} ${t("myFavorites").toLowerCase()}` : `${t("save")} ${song.title}`}
        >
          <MaterialIcon name={isFavorite ? "favorite" : "favorite_border"} size={18} />
          {isFavorite ? t("saved") : t("save")}
        </button>
      </div>
    </article>
  );
}
