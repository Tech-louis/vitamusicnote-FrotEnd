import { useEffect, useRef, useState } from "react";

import { languages } from "../../data/languages.js";
import { useTranslation } from "../../i18n/useTranslation.js";
import MaterialIcon from "./MaterialIcon.jsx";

export default function LanguageSwitcher() {
  const { t, language, setLanguage } = useTranslation();
  const [open, setOpen] = useState(false);
  const switcherRef = useRef(null);
  const selectedLanguage = languages.find((item) => item.code === language) || languages[0];

  useEffect(() => {
    function handlePointerDown(event) {
      if (!switcherRef.current?.contains(event.target)) setOpen(false);
    }
    function handleKeyDown(event) {
      if (event.key === "Escape") setOpen(false);
    }

    document.addEventListener("pointerdown", handlePointerDown);
    document.addEventListener("keydown", handleKeyDown);
    return () => {
      document.removeEventListener("pointerdown", handlePointerDown);
      document.removeEventListener("keydown", handleKeyDown);
    };
  }, []);

  return (
    <div className="vmn-language-switcher" ref={switcherRef}>
      <button
        type="button"
        className="vmn-language-current"
        aria-label={`${t("chooseLanguage", "Choose language")}: ${selectedLanguage.name}`}
        aria-haspopup="listbox"
        aria-expanded={open}
        onClick={() => setOpen((value) => !value)}
      >
        <img src={selectedLanguage.flag} alt="" width="24" height="18" />
        <span>{selectedLanguage.name}</span>
        <MaterialIcon name="expand_more" size={18} />
      </button>
      {open && (
        <div className="vmn-language-options" role="listbox" aria-label={t("chooseLanguage", "Choose language")}>
          {languages.map((item) => (
            <button
              type="button"
              key={item.code}
              role="option"
              aria-selected={language === item.code}
              className={`vmn-language-option ${language === item.code ? "is-selected" : ""}`}
              onClick={() => {
                setLanguage(item.code);
                setOpen(false);
              }}
            >
              <img src={item.flag} alt="" width="24" height="18" />
              <span>{item.name}</span>
              {language === item.code && <MaterialIcon name="check" size={18} />}
            </button>
          ))}
        </div>
      )}
    </div>
  );
}
