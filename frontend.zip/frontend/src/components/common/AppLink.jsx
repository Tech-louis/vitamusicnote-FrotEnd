import { Link } from '@tanstack/react-router'

const EXTERNAL = /^(https?:|mailto:|tel:|javascript:|data:)/i

/**
 * Drop-in replacement for <a href> that uses TanStack Router for internal
 * navigation while leaving external, mail, tel and hash-only links native.
 */
export default function AppLink({ href = '', to, children, ...rest }) {
  const target = to || href

  if (!target || EXTERNAL.test(target) || target.startsWith('#')) {
    return <a href={target || undefined} {...rest}>{children}</a>
  }

  const [pathname, hash = ''] = target.split('#')
  const path = pathname || '/'

  return (
    <Link to={path} hash={hash || undefined} {...rest}>
      {children}
    </Link>
  )
}
