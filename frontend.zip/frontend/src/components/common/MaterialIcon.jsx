export default function MaterialIcon({ name, className = "", size, ...props }) {
  return (
    <span
      className={`material-symbols-outlined ${className}`.trim()}
      style={size ? { fontSize: `${size}px` } : undefined}
      aria-hidden="true"
      {...props}
    >
      {name}
    </span>
  );
}
