import { useEffect, useRef, useState } from "react";
import { useTranslation } from "../../i18n/useTranslation.js";
import MaterialIcon from "./MaterialIcon.jsx";

export default function Modal({ open, title, onClose, children }) {
  const { t } = useTranslation();
  const dialogRef = useRef(null);
  const [visible, setVisible] = useState(open);

  useEffect(() => {
    if (open) {
      if (visible) return undefined;
      const frame = window.requestAnimationFrame(() => setVisible(true));
      return () => window.cancelAnimationFrame(frame);
    }
    if (!visible) return undefined;

    const timer = window.setTimeout(() => setVisible(false), 240);
    return () => window.clearTimeout(timer);
  }, [open, visible]);

  useEffect(() => {
    if (!open) return;
    const previous = document.activeElement;
    const dialog = dialogRef.current;
    const first = dialog?.querySelector("[data-autofocus]")
      || dialog?.querySelector("input:not([type='hidden'])")
      || dialog?.querySelector("button, a, select, textarea, [tabindex]:not([tabindex='-1'])");
    first?.focus();

    function onKeyDown(event) {
      if (event.key === "Escape") onClose();
      if (event.key !== "Tab" || !dialog) return;
      const items = [...dialog.querySelectorAll("button:not([disabled]), input:not([disabled]), a[href], select:not([disabled]), textarea:not([disabled]), [tabindex]:not([tabindex='-1'])")];
      if (!items.length) return;
      const firstItem = items[0], lastItem = items[items.length - 1];
      if (event.shiftKey && document.activeElement === firstItem) { event.preventDefault(); lastItem.focus(); }
      else if (!event.shiftKey && document.activeElement === lastItem) { event.preventDefault(); firstItem.focus(); }
    }
    document.addEventListener("keydown", onKeyDown);
    document.body.style.overflow = "hidden";
    return () => {
      document.removeEventListener("keydown", onKeyDown);
      document.body.style.overflow = "";
      previous?.focus?.();
    };
  }, [open, onClose]);

  if (!open && !visible) return null;
  return (
    <div
      className={`vmn-modal-backdrop ${open ? "is-entering" : "is-exiting"}`}
      role="presentation"
      aria-hidden={!open}
      inert={!open}
      onMouseDown={(event) => {
        if (open && event.target === event.currentTarget) onClose();
      }}
    >
      <section ref={dialogRef} className="vmn-modal" role="dialog" aria-modal="true" aria-labelledby="vmn-modal-title">
        <aside className="vmn-modal-art" aria-hidden="true">
          <div className="vmn-modal-art-brand">
            <MaterialIcon name="music_note" size={25} />
            <strong>VitaMusicNote</strong>
          </div>
          <div className="vmn-modal-art-copy">
            <span>{t("eyebrow", "Sacred & choral music")}</span>
            <h3>{t("brand", "Sacred Music Library")}</h3>
            <p>{t("heroDesc", "A digital library of sacred songs and choral music.")}</p>
          </div>
        </aside>
        <div className="vmn-modal-panel">
          <header className="vmn-modal-header">
            <h2 id="vmn-modal-title">{title || t("dialog")}</h2>
            <button className="vmn-modal-close" type="button" onClick={onClose}
              aria-label={t("close")} title={t("close")}>×</button>
          </header>
          {children}
        </div>
      </section>
    </div>
  );
}
