export function SplashScreen({ visible, theme = "light" }) {
  if (!visible) return null;
  return (
    <div className={`vmn-splash vmn-splash-${theme}`} role="status" aria-live="polite" aria-label="VitaMusicNote is loading">
      <div className="vmn-splash-content">
        <img src="/images/brand/vitamusicnote-logo.png" alt="" className="vmn-splash-logo" />
        <div className="vmn-splash-name">VitaMusicNote</div>
        <div className="vmn-splash-tagline">Sacred Music Library</div>
        <div className="vmn-splash-track"><span /></div>
        <span className="vmn-splash-caption">Preparing your music experience</span>
      </div>
    </div>
  );
}

export function GlobalProgressBar({ active }) {
  return (
    <div className={`vmn-global-progress ${active ? "is-active" : ""}`} aria-hidden="true">
      <span />
    </div>
  );
}

export function MusicCardSkeleton({ count = 3 }) {
  return (
    <div className="featured-grid vmn-skeleton-grid" aria-label="Loading music" role="status">
      {Array.from({ length: count }).map((_, index) => (
        <article className="music-card vmn-skeleton-card animate__animated animate__fadeInUp" key={index}>
          <div className="vmn-skeleton vmn-skeleton-cover" />
          <div className="vmn-skeleton-details">
            <div className="vmn-skeleton vmn-skeleton-line long" />
            <div className="vmn-skeleton vmn-skeleton-line medium" />
            <div className="vmn-skeleton vmn-skeleton-line short" />
          </div>
          <div className="vmn-skeleton-actions">
            <div className="vmn-skeleton vmn-skeleton-pill" />
            <div className="vmn-skeleton vmn-skeleton-button" />
          </div>
        </article>
      ))}
    </div>
  );
}
