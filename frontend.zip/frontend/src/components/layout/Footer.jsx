import AppLink from '../common/AppLink.jsx';
import MaterialIcon from "../common/MaterialIcon.jsx";
import { useTranslation } from "../../i18n/useTranslation.js";
import { useApp } from "../../state/AppContext.jsx";

export default function Footer() {
  const { t } = useTranslation();
  const { openLogin, openRegister } = useApp();
  const currentYear = new Date().getFullYear();
  const copyrightYears = currentYear > 2025 ? `2025–${currentYear}` : "2025";
  return (
    <footer className="footer" id="site-footer">
      <div className="footer-inner">
        <nav className="footer-links" aria-label="Footer navigation">
          <AppLink href="/about" className="animate__animated animate__fadeInUp">About VitaMusicNote</AppLink>
          <span aria-hidden="true">|</span>
          <AppLink href="/contact" className="animate__animated animate__fadeInUp">Contact</AppLink>
          <span aria-hidden="true">|</span>
          <AppLink href="/privacy-policy" className="animate__animated animate__fadeInUp">Privacy Policy</AppLink>
          <span aria-hidden="true">|</span>
          <AppLink href="/terms-of-service" className="animate__animated animate__fadeInUp">Terms of Service</AppLink>
          <span aria-hidden="true">|</span>
          <AppLink href="/dmca" className="animate__animated animate__fadeInUp">DMCA</AppLink>
          <span aria-hidden="true">|</span>
          <AppLink href="/copyright" className="animate__animated animate__fadeInUp">Copyright</AppLink>
          <span aria-hidden="true">|</span>
          <button type="button" onClick={openLogin} className="animate__animated animate__fadeInUp">{t("login")}</button>
          <span aria-hidden="true">|</span>
          <button type="button" onClick={openRegister} className="animate__animated animate__fadeInUp">Sign Up</button>
          <span aria-hidden="true">|</span>
          <AppLink href="/blog" className="animate__animated animate__fadeInUp">Blog</AppLink>
        </nav>

        <div className="footer-bottom-row">
          <div className="footer-socials" aria-label="Social media">
            <AppLink href="https://web.facebook.com/vitamusicnote" target="_blank" rel="noreferrer" aria-label="Facebook" className="animate__animated animate__fadeInUp">
              <svg className="footer-facebook-icon" viewBox="0 0 24 24" aria-hidden="true"><path fill="#1877F2" d="M13.4 21v-8h2.7l.4-3.1h-3.1V8c0-.9.3-1.5 1.6-1.5h1.7V3.7c-.3 0-1.4-.1-2.6-.1-2.6 0-4.3 1.6-4.3 4.5v1.8H7v3.1h2.8v8h3.6z"/></svg>
              <span>Facebook</span>
            </AppLink>

            <AppLink href="https://www.instagram.com/vitamusicnote/" target="_blank" rel="noreferrer" className="animate__animated animate__fadeInUp">
              <svg className="footer-instagram-icon" viewBox="0 0 24 24" aria-hidden="true">
                <rect x="3" y="3" width="18" height="18" rx="5" fill="none" stroke="currentColor" strokeWidth="2" />
                <circle cx="12" cy="12" r="4" fill="none" stroke="currentColor" strokeWidth="2" />
                <circle cx="17.5" cy="6.8" r="1.2" fill="currentColor" />
              </svg>
              <span>Instagram</span>
            </AppLink>
            <AppLink href="https://www.tiktok.com/@vitamusicnote" target="_blank" rel="noreferrer" className="animate__animated animate__fadeInUp">
              <svg className="footer-tiktok-icon" viewBox="0 0 24 24" aria-hidden="true">
                <path fill="currentColor" d="M19.6 7.1a6.8 6.8 0 0 1-4.2-1.5v9.1a6.1 6.1 0 1 1-5.3-6.05v3.2a2.9 2.9 0 1 0 2.1 2.8V2.5h3.2c.2 1.8 1.6 3.3 3.4 3.6.3.1.6.1.8.1v.9Z"/>
              </svg>
              <span>TikTok</span>
            </AppLink>
            <AppLink href="https://www.youtube.com/" target="_blank" rel="noreferrer" aria-label="YouTube" className="animate__animated animate__fadeInUp">
              <svg className="footer-youtube-icon" viewBox="0 0 24 24" aria-hidden="true" fill="#FF0000"><path d="M23 7.1a3 3 0 0 0-2.1-2.1C19 4.5 12 4.5 12 4.5s-7 0-8.9.5A3 3 0 0 0 1 7.1 31 31 0 0 0 .5 12s0 3.4.5 4.9a3 3 0 0 0 2.1 2.1c1.9.5 8.9.5 8.9.5s7 0 8.9-.5a3 3 0 0 0 2.1-2.1 31 31 0 0 0 .5-4.9s0-3.4-.5-4.9ZM9.7 15.5v-7l6 3.5z"/></svg>
              <span>YouTube</span>
            </AppLink>
          </div>

          <form className="footer-newsletter" onSubmit={(event) => event.preventDefault()}>
            <label className="sr-only" htmlFor="footer-newsletter-email">
              Newsletter email address
            </label>
            <input
              id="footer-newsletter-email"
              type="email"
              placeholder="Subscribe to newsletter"
              aria-label="Email address for newsletter"
            />
            <button type="submit" aria-label="Subscribe to newsletter">
              <MaterialIcon name="mail" size={17} />
            </button>
          </form>
        </div>

        <div className="footer-copyright">
          <img
            src="/images/brand/vitamusicnote-logo.png"
            alt=""
            className="footer-brand-logo"
            width="24"
            height="24"
          />
          <span>© {copyrightYears} VitaMusicNote. {t("rights")}</span>
        </div>
      </div>
    </footer>
  );
}
