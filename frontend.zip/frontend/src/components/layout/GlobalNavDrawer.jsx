import { useEffect } from "react";
import { createPortal } from "react-dom";
import { useRouterState } from "@tanstack/react-router";

import { useTranslation } from "../../i18n/useTranslation.js";
import { useNavOverlay } from "../../state/NavOverlayContext.jsx";
import { getPublicNav } from "./header/headerConfig.js";
import MobileDrawer from "./header/MobileDrawer.jsx";
import "./header/globalOverlay.css";

export default function GlobalNavDrawer() {
  const { t } = useTranslation();
  const { drawerOpen, closeDrawer } = useNavOverlay();
  const location = useRouterState({
    select: (state) => ({
      pathname: state.location.pathname,
      hash: state.location.hash,
    }),
  });
  const navItems = getPublicNav(t);

  function isActive(item) {
    if (item.href.includes("#")) {
      return location.pathname === "/" && location.hash === `#${item.href.split("#")[1]}`;
    }
    return location.pathname === item.href;
  }

  useEffect(() => {
    function handleKeyDown(event) {
      if (event.key === "Escape") closeDrawer();
    }
    document.addEventListener("keydown", handleKeyDown);
    return () => document.removeEventListener("keydown", handleKeyDown);
  }, [closeDrawer]);

  useEffect(() => {
    document.body.style.overflow = drawerOpen ? "hidden" : "";
    return () => {
      document.body.style.overflow = "";
    };
  }, [drawerOpen]);

  if (typeof document === "undefined") return null;

  return createPortal(
    <MobileDrawer open={drawerOpen} onClose={closeDrawer} navItems={navItems} isActive={isActive} />,
    document.body,
  );
}
