import { useEffect, useState } from 'react'
import { useNavigate, useRouterState } from '@tanstack/react-router'

import AppLink from '../common/AppLink.jsx'
import LanguageSwitcher from '../common/LanguageSwitcher.jsx'
import MaterialIcon from '../common/MaterialIcon.jsx'
import { useApp } from '../../state/AppContext.jsx'
import { dashboardNav, dashboardProfile } from '../../data/vstudioDashboard.js'
import { getProfilePhoto, handleAvatarError } from '../../data/profile.js'
import { isActivePath } from './header/headerConfig.js'
import VStudioLoader from '../../pages/vstudio/VStudioLoader.jsx'
import '../../pages/vstudio/vstudioDesign.css'
import './VStudioLayout.css'

const PAGE_TITLES = {
  '/vstudio/profile': 'Wasifu',
  '/vstudio/settings': 'Mipangilio',
}

const ACCOUNT_PATHS = ['/vstudio/profile', '/vstudio/settings']
const RAIL_KEY = 'vitamusicnote-vstudio-rail'

function readRailState() {
  try {
    return localStorage.getItem(RAIL_KEY) === 'collapsed'
  } catch {
    return false
  }
}

export default function VStudioLayout({ children, user }) {
  const navigate = useNavigate()
  const location = useRouterState({
    select: (state) => ({ pathname: state.location.pathname, hash: state.location.hash }),
  })
  const { authLoading, handleLogout, openLogin } = useApp()
  const [navOpen, setNavOpen] = useState(false)
  const [introLoading, setIntroLoading] = useState(true)
  const [collapsed, setCollapsed] = useState(readRailState)

  useEffect(() => {
    const timer = window.setTimeout(() => setIntroLoading(false), 620)
    return () => window.clearTimeout(timer)
  }, [])

  useEffect(() => {
    try {
      localStorage.setItem(RAIL_KEY, collapsed ? 'collapsed' : 'expanded')
    } catch {
      // Storage may be unavailable; the rail still works for this session.
    }
  }, [collapsed])

  useEffect(() => {
    if (!navOpen) return

    function handleKeyDown(event) {
      if (event.key === 'Escape') setNavOpen(false)
    }

    const previousOverflow = document.body.style.overflow
    document.body.style.overflow = 'hidden'
    document.addEventListener('keydown', handleKeyDown)

    return () => {
      document.body.style.overflow = previousOverflow
      document.removeEventListener('keydown', handleKeyDown)
    }
  }, [navOpen])

  const name = user
    ? [user.first_name, user.last_name].filter(Boolean).join(' ')
      || user.email?.split('@')[0]
      || dashboardProfile.fallbackName
    : dashboardProfile.fallbackName
  const greeting = `Karibu tena, ${name.split(/\s+/)[0].toLowerCase()}`
  const pageTitle = PAGE_TITLES[location.pathname] || dashboardProfile.title
  const primaryNav = dashboardNav.filter((item) => !ACCOUNT_PATHS.includes(item.href))
  const accountNav = dashboardNav.filter((item) => ACCOUNT_PATHS.includes(item.href))

  function closeNav() {
    setNavOpen(false)
  }

  function isNavActive(item) {
    if (item.href.startsWith('#')) return location.hash === item.href
    return isActivePath(location.pathname, item.href)
  }

  async function logout() {
    closeNav()
    await handleLogout()
    navigate({ to: '/' })
  }

  function renderNavItem(item) {
    const active = isNavActive(item)
    return (
      <AppLink
        key={item.label}
        href={item.href}
        className={`vstudio-nav-link animate__animated animate__fadeInUp ${active ? 'is-active' : ''}`.trim()}
        aria-current={active ? 'page' : undefined}
        title={collapsed ? item.label : undefined}
        onClick={closeNav}
      >
        <span className="vstudio-nav-icon"><MaterialIcon name={item.icon} size={18} /></span>
        <span className="vstudio-nav-text">{item.label}</span>
        {active && <span className="vstudio-nav-dot" aria-hidden="true" />}
      </AppLink>
    )
  }

  const shellClass = [
    'vstudio-shell',
    navOpen ? 'is-nav-open' : '',
    collapsed ? 'is-collapsed' : '',
  ].filter(Boolean).join(' ')

  return (
    <>
      {introLoading && <VStudioLoader />}
      <div className={shellClass}>
        <aside className="vstudio-sidebar" id="vstudio-sidebar">
          <div className="vstudio-brand">
            <img src="/images/brand/vitamusicnote-logo.png" alt="" />
            <div className="vstudio-brand-copy">
              <strong>VStudio</strong>
              <span>Creator console</span>
            </div>
            <button
              type="button"
              className="vstudio-collapse"
              onClick={() => setCollapsed((current) => !current)}
              aria-label={collapsed ? 'Expand side menu' : 'Collapse side menu'}
              aria-expanded={!collapsed}
            >
              <MaterialIcon name={collapsed ? 'chevron_right' : 'chevron_left'} size={16} />
            </button>
          </div>

          <AppLink
            href="/vstudio/profile"
            className="vstudio-account-card animate__animated animate__fadeInUp"
            title={collapsed ? name : undefined}
            onClick={closeNav}
          >
            <img src={getProfilePhoto(user?.photo)} alt="" onError={handleAvatarError} />
            <div>
              <span>{dashboardProfile.accountLabel}</span>
              <strong>{name}</strong>
            </div>
            <MaterialIcon name="chevron_right" size={16} />
          </AppLink>

          <div className="vstudio-nav-groups">
            <section className="vstudio-nav-group">
              <p className="vstudio-nav-label">Studio</p>
              <nav aria-label="Studio navigation">{primaryNav.map(renderNavItem)}</nav>
            </section>

            <section className="vstudio-nav-group">
              <p className="vstudio-nav-label">Account</p>
              <nav aria-label="Account navigation">{accountNav.map(renderNavItem)}</nav>
            </section>
          </div>

          <div className="vstudio-sidebar-foot">
            <div className="vstudio-help-card" title={collapsed ? 'Studio tips' : undefined}>
              <MaterialIcon name="bolt" size={16} />
              <div><strong>Studio tips</strong><small>Keep creating, keep growing</small></div>
            </div>
            {user ? (
              <button
                type="button"
                className="vstudio-foot-link vstudio-logout"
                onClick={logout}
                disabled={authLoading}
                title={collapsed ? 'Log out' : undefined}
              >
                <MaterialIcon name="logout" size={17} />
                <span>Log out</span>
              </button>
            ) : (
              <button
                type="button"
                className="vstudio-foot-link"
                onClick={() => { closeNav(); openLogin(); }}
                title={collapsed ? 'Login' : undefined}
              >
                <MaterialIcon name="login" size={17} />
                <span>Login</span>
              </button>
            )}
          </div>
        </aside>

        {navOpen && (
          <button
            type="button"
            className="vstudio-scrim"
            onClick={closeNav}
            aria-label="Close menu"
          />
        )}

        <div className="vstudio-workspace">
          <header className="vstudio-topbar">
            <button
              type="button"
              className="vstudio-icon-button vstudio-menu-button"
              onClick={() => setNavOpen(true)}
              aria-controls="vstudio-sidebar"
              aria-expanded={navOpen}
              aria-label="Open menu"
            >
              <MaterialIcon name="menu" size={22} />
            </button>

            <div className="vstudio-topbar-heading">
              <h1>{pageTitle}</h1>
              <p>{greeting}</p>
            </div>

            <div className="vstudio-topbar-tools">
              <span className="vstudio-live-chip"><i aria-hidden="true" /><span>Studio live</span></span>
              <AppLink href="#uploads" className="vstudio-topbar-upload" onClick={closeNav}>
                <MaterialIcon name="upload" size={15} /> Upload
              </AppLink>
              <div className="vstudio-topbar-language">
                <LanguageSwitcher />
              </div>
            </div>
          </header>

          <main id="main-content" className="vstudio-content" tabIndex="-1">
            {children}
          </main>
        </div>
      </div>
    </>
  )
}
