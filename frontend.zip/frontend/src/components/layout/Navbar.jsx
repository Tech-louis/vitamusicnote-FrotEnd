import { useRouterState } from "@tanstack/react-router";

import AppLink from "../common/AppLink.jsx";
import LanguageSwitcher from "../common/LanguageSwitcher.jsx";
import MaterialIcon from "../common/MaterialIcon.jsx";
import { useTranslation } from "../../i18n/useTranslation.js";
import { useApp } from "../../state/AppContext.jsx";
import { useNavOverlay } from "../../state/NavOverlayContext.jsx";
import { getPublicNav } from "./header/headerConfig.js";
import "./header/header.css";
import "./header/globalOverlay.css";

export default function Navbar() {
  const { t } = useTranslation();
  const { isAuthenticated, authChecking, openLogin, openRegister, theme, setTheme } = useApp();
  const { drawerOpen, toggleDrawer } = useNavOverlay();
  const location = useRouterState({
    select: (state) => ({
      pathname: state.location.pathname,
      hash: state.location.hash,
    }),
  });
  const navItems = getPublicNav(t);
  const signedIn = !authChecking && isAuthenticated;

  function isActive(item) {
    if (item.href.includes("#")) {
      return location.pathname === "/" && location.hash === `#${item.href.split("#")[1]}`;
    }
    return location.pathname === item.href;
  }

  return (
    <header className="vmn-public-header">
      <div className="vmn-public-header-inner">
        <AppLink href="/" className="vmn-public-brand" aria-label="VitaMusicNote home">
          <img src="/images/brand/vitamusicnote-logo.png" alt="" width="42" height="42" />
          <span>Vitamusicnote</span>
        </AppLink>

        <nav className="vmn-public-nav" aria-label={t("mainNavigation", "Main navigation")}>
          {navItems.map((item) => {
            const active = isActive(item);
            return (
              <AppLink
                key={item.href}
                href={item.href}
                className={`vmn-public-nav-link animate__animated animate__fadeInUp ${active ? "is-active" : ""}`}
                aria-current={active ? "page" : undefined}
              >
                <MaterialIcon name={item.icon} size={19} />
                {item.label}
              </AppLink>
            );
          })}
        </nav>

        <div className="vmn-public-header-actions">
          <button
            type="button"
            className="vmn-public-theme-toggle"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            aria-label={theme === "dark" ? t("lightMode", "Light mode") : t("darkMode", "Dark mode")}
            title={theme === "dark" ? t("lightMode", "Light mode") : t("darkMode", "Dark mode")}
            aria-pressed={theme === "dark"}
          >
            <MaterialIcon name={theme === "dark" ? "light_mode" : "dark_mode"} size={22} />
          </button>
          <div className="vmn-public-header-language"><LanguageSwitcher /></div>
          <div className="vmn-public-auth">
            {signedIn ? (
              <AppLink href="/vstudio" className="vmn-public-auth-link is-solid">
                {t("vitaStudio", "VStudio")}
              </AppLink>
            ) : (
              <>
                <button type="button" onClick={openLogin} className="vmn-public-auth-link is-outline">
                  {t("login", "Login")}
                </button>
                <button type="button" onClick={openRegister} className="vmn-public-auth-link is-solid">
                  {t("signup", "Sign up")}
                </button>
              </>
            )}
          </div>
          <button
            type="button"
            onClick={toggleDrawer}
            className="vmn-public-menu-button"
            aria-label={drawerOpen ? t("close", "Close menu") : t("toggleMenu", "Open menu")}
            aria-expanded={drawerOpen}
            aria-controls="mobile-drawer"
            data-nav-overlay
          >
            <MaterialIcon name={drawerOpen ? "close" : "menu"} size={27} />
          </button>
        </div>
      </div>
    </header>
  );
}
