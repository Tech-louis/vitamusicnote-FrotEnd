export const iconButtonClass =
  "relative inline-flex h-10 w-10 shrink-0 items-center justify-center rounded-full text-[#37473d] transition-all hover:bg-[#f1f6f2] hover:text-brand active:scale-95 focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/40 dark:text-[#d5e2d8] dark:hover:bg-[#1d3326] dark:hover:text-[#9fe0b8]";

export const panelClass =
  "absolute right-0 top-[calc(100%+10px)] z-50 rounded-2xl border border-[#e3e9e4] bg-white/95 p-2 shadow-[0_20px_60px_rgba(16,35,22,0.18)] backdrop-blur-xl [animation:vmn-pop_0.16s_ease-out] dark:border-[#304236] dark:bg-[#18231c]/95";

export const drawerItemClass =
  "flex min-h-[44px] items-center gap-2.5 rounded-xl px-3 py-2 text-sm font-semibold text-[#2c3c32] transition-colors hover:bg-brand-soft hover:text-brand dark:text-[#e8f1ea] dark:hover:bg-[#1d3326] dark:hover:text-[#9fe0b8]";

export function drawerLinkClass(active) {
  return active
    ? "flex min-h-[44px] items-center gap-2.5 rounded-xl bg-brand px-3 py-2 text-sm font-semibold text-white shadow-sm dark:bg-[#2f7d4f]"
    : drawerItemClass;
}

export const primaryButtonClass =
  "inline-flex h-10 items-center justify-center rounded-full bg-brand px-4 text-[13px] font-bold text-white shadow-sm transition-all hover:-translate-y-0.5 hover:bg-brand-dark hover:shadow-md focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/50";

export const secondaryButtonClass =
  "inline-flex h-10 items-center justify-center rounded-full border border-[#cfe0d4] px-4 text-[13px] font-bold text-brand transition-all hover:bg-brand-soft focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/40 dark:border-[#3b5142] dark:text-[#9fe0b8] dark:hover:bg-[#1d3326]";

export function navLinkClass(active) {
  return [
    "relative inline-flex h-9 items-center rounded-full px-3.5 text-[13px] font-semibold transition-all",
    "focus-visible:outline-none focus-visible:ring-2 focus-visible:ring-brand/40",
    active
      ? "bg-brand text-white shadow-sm dark:bg-[#2f7d4f]"
      : "text-[#425247] hover:bg-white hover:text-brand hover:shadow-sm dark:text-[#cbd9cf] dark:hover:bg-[#1d3326] dark:hover:text-[#9fe0b8]",
  ].join(" ");
}
