import { useEffect, useRef } from "react";

import AppLink from "../../common/AppLink.jsx";
import MaterialIcon from "../../common/MaterialIcon.jsx";
import { useTranslation } from "../../../i18n/useTranslation.js";
import { useApp } from "../../../state/AppContext.jsx";

export default function MobileDrawer({ open, onClose, navItems, isActive }) {
  const { t } = useTranslation();
  const { isAuthenticated, authChecking, openLogin, openRegister, theme, setTheme } = useApp();
  const drawerRef = useRef(null);
  const signedIn = !authChecking && isAuthenticated;

  useEffect(() => {
    if (open) drawerRef.current?.querySelector("a, button")?.focus();
  }, [open]);

  return (
    <div
      className={`vmn-header-drawer-overlay ${open ? "is-open" : ""}`}
      aria-hidden={!open}
      inert={!open}
    >
      <button
        className="vmn-header-drawer-backdrop"
        type="button"
        aria-label={t("close", "Close menu")}
        tabIndex={open ? 0 : -1}
        onClick={onClose}
      />
      <aside
        id="mobile-drawer"
        ref={drawerRef}
        className="vmn-header-drawer"
        role="dialog"
        aria-modal="true"
        aria-label={t("mainNavigation", "Main navigation")}
        data-nav-overlay
      >
        <div className="vmn-header-drawer-head">
          <strong>{t("menu", "Menu")}</strong>
          <button type="button" className="vmn-header-drawer-close" onClick={onClose} aria-label={t("close", "Close menu")}>
            <MaterialIcon name="close" size={23} />
          </button>
        </div>

        <nav className="vmn-header-drawer-links" aria-label={t("mainNavigation", "Main navigation")}>
          {navItems.map((item) => {
            const active = isActive(item);
            return (
              <AppLink
                key={item.href}
                href={item.href}
                onClick={onClose}
                className={`vmn-header-drawer-link animate__animated animate__fadeInUp ${active ? "is-active" : ""}`}
                aria-current={active ? "page" : undefined}
              >
                <MaterialIcon name={item.icon} size={21} />
                <span>{item.label}</span>
                <MaterialIcon name="arrow_forward" size={18} className="vmn-drawer-arrow" />
              </AppLink>
            );
          })}
        </nav>

        <div className="vmn-header-drawer-setting">
          <span>{theme === "dark" ? t("lightMode", "Light mode") : t("darkMode", "Dark mode")}</span>
          <button
            type="button"
            className="vmn-public-theme-toggle"
            onClick={() => setTheme(theme === "dark" ? "light" : "dark")}
            aria-label={theme === "dark" ? t("lightMode", "Light mode") : t("darkMode", "Dark mode")}
            title={theme === "dark" ? t("lightMode", "Light mode") : t("darkMode", "Dark mode")}
            aria-pressed={theme === "dark"}
          >
            <MaterialIcon name={theme === "dark" ? "light_mode" : "dark_mode"} size={20} />
          </button>
        </div>

        <div className="vmn-header-drawer-auth">
          {signedIn ? (
            <AppLink href="/vstudio" className="vmn-public-auth-link is-solid" onClick={onClose}>
              {t("vitaStudio", "VStudio")}
            </AppLink>
          ) : (
            <>
              <button
                type="button"
                className="vmn-public-auth-link is-outline"
                onClick={() => { onClose(); openLogin(); }}
              >
                {t("login", "Login")}
              </button>
              <button
                type="button"
                className="vmn-public-auth-link is-solid"
                onClick={() => { onClose(); openRegister(); }}
              >
                {t("signup", "Sign up")}
              </button>
            </>
          )}
        </div>
      </aside>
    </div>
  );
}
