/** Shared navigation definitions for the public header. */
export function getPublicNav(t) {
  return [
    { href: "/", label: t("home", "Home"), icon: "home" },
    { href: "/about", label: t("about", "About"), icon: "info" },
    { href: "/songs", label: t("allSongs", "All Songs"), icon: "library_music" },
    { href: "/liturgical-calendar", label: t("liturgicalCalendar", "Liturgical Calendar"), icon: "calendar_month" },
    { href: "/blog", label: t("blog", "Blog"), icon: "article" },
  ];
}

/** A link is active when the current path is the target or one of its children. */
export function isActivePath(currentPath, href) {
  const path = href.split("#")[0].replace(/\/+$/, "") || "/";
  const current = String(currentPath || "/").replace(/\/+$/, "") || "/";
  return path === "/" ? current === "/" : current === path || current.startsWith(`${path}/`);
}
