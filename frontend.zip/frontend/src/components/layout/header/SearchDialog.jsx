import { useCallback, useEffect, useMemo, useRef, useState } from "react";

import AppLink from "../../common/AppLink.jsx";
import MaterialIcon from "../../common/MaterialIcon.jsx";
import { normalizeQuery, searchSuggestions } from "../../../services/catalogSearch.js";

const RECENT_SEARCH_KEY = "vitamusicnote-recent-searches";
const MAX_RECENT = 5;

function readRecentSearches() {
  if (typeof window === "undefined") return [];
  try {
    const saved = JSON.parse(window.localStorage.getItem(RECENT_SEARCH_KEY) || "[]");
    return Array.isArray(saved)
      ? saved.filter((item) => typeof item === "string").slice(0, MAX_RECENT)
      : [];
  } catch {
    return [];
  }
}

export default function SearchDialog({ t, quickLinks, onClose, onSearch }) {
  const [query, setQuery] = useState("");
  const [kind, setKind] = useState("all");
  const [activeIndex, setActiveIndex] = useState(-1);
  const [recentSearches, setRecentSearches] = useState(readRecentSearches);
  const inputRef = useRef(null);

  const allSuggestions = useMemo(() => searchSuggestions(query), [query]);
  const suggestions = useMemo(
    () => (kind === "all" ? allSuggestions : allSuggestions.filter((item) => item.kind === kind)),
    [allSuggestions, kind],
  );
  const hasQuery = Boolean(normalizeQuery(query));
  const highlighted = activeIndex >= 0 && activeIndex < suggestions.length ? activeIndex : -1;

  const saveRecent = useCallback((value) => {
    const term = normalizeQuery(value);
    if (!term) return;
    setRecentSearches((current) => {
      const next = [term, ...current.filter((item) => item.toLocaleLowerCase() !== term.toLocaleLowerCase())].slice(0, MAX_RECENT);
      try {
        window.localStorage.setItem(RECENT_SEARCH_KEY, JSON.stringify(next));
      } catch {
        // Storage is optional.
      }
      return next;
    });
  }, []);

  const run = useCallback((value) => {
    const term = normalizeQuery(value);
    if (term) saveRecent(term);
    onSearch(term);
    onClose();
  }, [onClose, onSearch, saveRecent]);

  const pickSuggestion = useCallback((item) => {
    if (item) run(item.query);
  }, [run]);

  const clearRecent = useCallback(() => {
    setRecentSearches([]);
    try {
      window.localStorage.removeItem(RECENT_SEARCH_KEY);
    } catch {
      // Storage is optional.
    }
  }, []);

  useEffect(() => {
    inputRef.current?.focus();
  }, []);

  function handleSubmit(event) {
    event.preventDefault();
    run(query);
  }

  function handleInputKeyDown(event) {
    if (event.key === "ArrowDown" && suggestions.length) {
      event.preventDefault();
      setActiveIndex((index) => (index + 1) % suggestions.length);
    } else if (event.key === "ArrowUp" && suggestions.length) {
      event.preventDefault();
      setActiveIndex((index) => (index <= 0 ? suggestions.length - 1 : index - 1));
    } else if (event.key === "Enter" && highlighted >= 0) {
      event.preventDefault();
      pickSuggestion(suggestions[highlighted]);
    }
  }

  return (
    <div
      className="vmn-search-overlay-layer fixed inset-0 z-[80] flex items-start justify-center bg-[#0b140e]/60 px-4 pt-[8vh] backdrop-blur-sm"
      onMouseDown={onClose}
    >
      <div
        role="dialog"
        aria-modal="true"
        aria-label={t("search")}
        data-nav-overlay
        onMouseDown={(event) => event.stopPropagation()}
        className="w-full max-w-2xl overflow-hidden rounded-2xl border border-[#e3e9e4] bg-white shadow-2xl [animation:vmn-pop_0.16s_ease-out] dark:border-[#304236] dark:bg-[#18231c]"
      >
        <form onSubmit={handleSubmit} className="flex items-center gap-2 border-b border-[#edf1ed] px-4 dark:border-[#2d3d33]">
          <MaterialIcon name="search" size={20} className="shrink-0 text-brand" />
          <input
            ref={inputRef}
            type="search"
            value={query}
            onChange={(event) => {
              setQuery(event.target.value);
              setActiveIndex(-1);
            }}
            onKeyDown={handleInputKeyDown}
            placeholder={t("searchSongsComposers")}
            aria-label={t("search")}
            className="h-14 min-w-0 flex-1 bg-transparent text-[15px] text-[#25342a] outline-none placeholder:text-[#9aa69d] dark:text-[#e8f1ea]"
          />
          {query && (
            <button
              type="button"
              onClick={() => {
                setQuery("");
                setActiveIndex(-1);
                inputRef.current?.focus();
              }}
              aria-label={t("close")}
              className="rounded-full p-1.5 text-[#8b968e] hover:bg-[#f1f6f2] dark:hover:bg-[#1d3326]"
            >
              <MaterialIcon name="close" size={16} />
            </button>
          )}
          <kbd className="hidden rounded border border-[#dde5df] px-1.5 py-0.5 text-[10px] font-bold text-[#8b968e] sm:block dark:border-[#3a4d40]">
            ESC
          </kbd>
        </form>

        {hasQuery && (
          <div className="vmn-search-tabs" role="tablist" aria-label={t("search")}>
            {[
              { key: "all", label: t("all", "All") },
              { key: "song", label: t("songs") },
              { key: "composer", label: t("composers") },
            ].map((tab) => (
              <button
                key={tab.key}
                type="button"
                role="tab"
                aria-selected={kind === tab.key}
                onClick={() => { setKind(tab.key); setActiveIndex(-1); }}
                className={`vmn-search-tab animate__animated animate__fadeInUp ${kind === tab.key ? "is-active" : ""}`}
              >
                {tab.label}
              </button>
            ))}
          </div>
        )}

        <div className="max-h-[52vh] overflow-y-auto p-2">
          {hasQuery ? (
            <>
              <p className="px-3 pb-1 pt-2 text-[10px] font-bold uppercase tracking-wider text-[#8b968e]">
                {t("suggestions")}
              </p>
              {suggestions.length ? (
                <ul role="listbox" aria-label={t("suggestions")}>
                  {suggestions.map((item, index) => {
                    const iconName = item.kind === "composer" ? "person" : "music_note";
                    return (
                      <li key={item.id} role="option" aria-selected={index === highlighted}>
                        <button
                          type="button"
                          onMouseEnter={() => setActiveIndex(index)}
                          onClick={() => pickSuggestion(item)}
                          className={`animate__animated animate__fadeInUp flex w-full items-center gap-3 rounded-xl px-3 py-2.5 text-left transition-colors ${
                            index === highlighted
                              ? "bg-brand-soft dark:bg-[#1d3326]"
                              : "hover:bg-[#f5f8f5] dark:hover:bg-[#1d3326]/60"
                          }`}
                        >
                          <span className="grid h-9 w-9 shrink-0 place-items-center rounded-lg bg-white text-brand shadow-sm dark:bg-[#202d24]">
                            <MaterialIcon name={iconName} size={16} />
                          </span>
                          <span className="min-w-0 flex-1">
                            <strong className="block truncate text-[13px] text-[#25342a] dark:text-[#e8f1ea]">
                              {item.label}
                            </strong>
                            <span className="block truncate text-[11px] text-[#78837b] dark:text-[#a9b9ae]">
                              {item.meta}
                            </span>
                          </span>
                          <MaterialIcon name="arrow_outward" size={16} className="shrink-0 text-[#a7b2a9]" />
                        </button>
                      </li>
                    );
                  })}
                </ul>
              ) : (
                <p className="px-3 py-6 text-center text-xs text-[#78837b] dark:text-[#a9b9ae]">
                  {t("noResults")}
                </p>
              )}

              <button
                type="submit"
                className="mt-2 flex w-full items-center justify-center gap-2 rounded-xl border border-dashed border-[#cfe0d4] px-3 py-2.5 text-xs font-bold text-brand transition-colors hover:bg-brand-soft dark:border-[#3b5142] dark:hover:bg-[#1d3326]"
              >
                {t("viewAll")} “{normalizeQuery(query)}”
                <MaterialIcon name="arrow_outward" size={14} />
              </button>
            </>
          ) : (
            <>
              {recentSearches.length > 0 && (
                <section className="px-1 pb-2">
                  <div className="flex items-center justify-between px-2 pt-2">
                    <p className="text-[10px] font-bold uppercase tracking-wider text-[#8b968e]">
                      {t("recentSearches")}
                    </p>
                    <button
                      type="button"
                      onClick={clearRecent}
                      className="text-[11px] font-bold text-brand hover:underline"
                    >
                      {t("clearRecent")}
                    </button>
                  </div>
                  <div className="mt-1 flex flex-wrap gap-1.5 px-2">
                    {recentSearches.map((item) => (
                      <button
                        key={item}
                        type="button"
                        onClick={() => run(item)}
                        className="animate__animated animate__fadeInUp inline-flex items-center gap-1.5 rounded-full border border-[#e1e8e2] bg-white px-2.5 py-1.5 text-[11px] font-semibold text-[#5d6860] hover:border-brand hover:text-brand dark:border-[#34483a] dark:bg-[#202d24] dark:text-[#cbd9cf]"
                      >
                        <MaterialIcon name="history" size={12} />
                        {item}
                      </button>
                    ))}
                  </div>
                </section>
              )}

              <section className="px-1">
                <p className="px-2 pb-1 pt-2 text-[10px] font-bold uppercase tracking-wider text-[#8b968e]">
                  {t("quickLinks")}
                </p>
                <div className="grid gap-1 sm:grid-cols-2">
                  {quickLinks.map((item) => {
                    return (
                      <AppLink
                        key={item.href}
                        href={item.href}
                        onClick={onClose}
                        className="animate__animated animate__fadeInUp flex items-center gap-2.5 rounded-xl px-3 py-2.5 text-[13px] font-semibold text-[#334238] hover:bg-brand-soft hover:text-brand dark:text-[#d5e2d8] dark:hover:bg-[#1d3326]"
                      >
                        <MaterialIcon
                          name={typeof item.icon === "string" ? item.icon : "link"}
                          size={16}
                          className="text-brand"
                        />
                        <span className="min-w-0 flex-1 truncate">{item.label}</span>
                        <MaterialIcon name="arrow_outward" size={14} className="text-[#a7b2a9]" />
                      </AppLink>
                    );
                  })}
                </div>
              </section>
            </>
          )}
        </div>

        <footer className="flex flex-wrap items-center justify-between gap-2 border-t border-[#edf1ed] px-4 py-2.5 text-[11px] text-[#8b968e] dark:border-[#2d3d33]">
          <span>{t("searchHint")}</span>
          {suggestions.length > 0 && (
            <span className="hidden items-center gap-2 sm:flex">
              <span>↑↓ {t("navigate")}</span>
              <span>↵ {t("select")}</span>
            </span>
          )}
        </footer>
      </div>
    </div>
  );
}
