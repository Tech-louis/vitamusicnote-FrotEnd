import Navbar from "./Navbar.jsx";
import Footer from "./Footer.jsx";

export default function PublicLayout({ children }) {
  return (
    <div className="public-layout">
      <Navbar />
      <div className="container">{children}</div>
      <Footer />
    </div>
  );
}
