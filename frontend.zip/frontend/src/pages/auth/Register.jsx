import { useState } from "react";
import AppLink from '../../components/common/AppLink.jsx';
import { useTranslation } from "../../i18n/useTranslation.js";
import "./Login.css";

export default function Register({
  onRegister, onGoogleSignup, onGoogleError, onLogin, onHome,
  loading = false, error = "", captchaSlot = null,
}) {
  const { t } = useTranslation();
  const [googleExpanded, setGoogleExpanded] = useState(true);
  const [emailExpanded, setEmailExpanded] = useState(false);
  const [showPassword, setShowPassword] = useState(false);
  const [showConfirm, setShowConfirm] = useState(false);
  const [form, setForm] = useState({
    firstName: "", lastName: "", email: "", password: "",
    passwordConfirm: "", privacyPolicy: false, newsletter: true,
  });

  function update(field, value) {
    setForm((current) => ({ ...current, [field]: value }));
  }

  function handleGoogleClick(event) {
    if (onGoogleSignup) return;
    event.preventDefault();
    onGoogleError?.();
  }

  function handleSubmit(event) {
    event.preventDefault();
    onRegister?.({
      first_name: form.firstName.trim(),
      last_name: form.lastName.trim(),
      email: form.email.trim(),
      password: form.password,
      password_confirmation: form.passwordConfirm,
      newsletter: form.newsletter,
      privacy_policy: form.privacyPolicy,
      timezone: Intl.DateTimeFormat().resolvedOptions().timeZone,
    });
  }

  return (
    <section className="vmn-auth-card vmn-register-card" aria-labelledby="vmn-register-title">
      <header className="vmn-login-brand">
        <img className="vmn-login-logo" src="/images/brand/vitamusicnote-logo.png" alt="VitaMusicNote" />
        <div className="vmn-login-brand-copy">
          <span className="vmn-login-brand-name">VitaMusicNote</span>
          <span className="vmn-login-brand-tagline">{t("brand")}</span>
        </div>
      </header>

      <div className="vmn-login-intro">
        <h1 id="vmn-register-title">{t("registerTitle")}</h1>
        <p>{t("registerDescription")}</p>
      </div>

      <div className="vmn-register-google-wrap">
        {googleExpanded ? (
          <div className="vmn-register-google-card">
            <span className="vmn-register-badge">✦ {t("recommended")}</span>
            <h2>{t("googleSignupTitle")}</h2>
            <p>{t("googleSignupDescription")}</p>
            <a
              className={`vmn-google-button ${onGoogleSignup ? "" : "is-disabled"}`}
              href={onGoogleSignup || undefined}
              onClick={handleGoogleClick}
              aria-disabled={onGoogleSignup ? undefined : "true"}
              data-autofocus
            >
              <span className="vmn-google-g" aria-hidden="true">G</span>
              <span>{t("continueGoogle")}</span>
            </a>
            <button type="button" className="vmn-register-collapse"
              onClick={() => { setGoogleExpanded(false); setEmailExpanded(true); }}>
              {t("useEmailInstead")}
            </button>
          </div>
        ) : (
          <button type="button" className="vmn-register-mini"
            onClick={() => { setGoogleExpanded(true); setEmailExpanded(false); }}>
            <span><b className="vmn-google-g">G</b> {t("continueGoogle")}</span>
            <span aria-hidden="true">⌄</span>
          </button>
        )}
      </div>

      {!googleExpanded && <div className="vmn-login-divider"><span /><span>{t("orEmailRegistration")}</span><span /></div>}

      <button type="button" className="vmn-register-email-toggle"
        aria-expanded={emailExpanded}
        onClick={() => {
          const next = !emailExpanded;
          setEmailExpanded(next);
          if (next) setGoogleExpanded(false);
        }}>
        <span><span className="vmn-register-email-icon" aria-hidden="true">✉</span>{t("useEmailInstead")}</span>
        <span aria-hidden="true">{emailExpanded ? "⌃" : "⌄"}</span>
      </button>

      {emailExpanded && (
        <form className="vmn-login-form vmn-register-form" onSubmit={handleSubmit} aria-busy={loading}>
          <div className="vmn-register-grid">
            <div>
              <label htmlFor="vmn-first-name">{t("firstName")}</label>
              <input id="vmn-first-name" autoComplete="given-name" value={form.firstName}
                onChange={(e) => update("firstName", e.target.value)} required placeholder={t("firstName")} />
            </div>
            <div>
              <label htmlFor="vmn-last-name">{t("lastName")}</label>
              <input id="vmn-last-name" autoComplete="family-name" value={form.lastName}
                onChange={(e) => update("lastName", e.target.value)} required placeholder={t("lastName")} />
            </div>
          </div>

          <label htmlFor="vmn-register-email">{t("emailAddress")}</label>
          <input id="vmn-register-email" type="email" autoComplete="email" value={form.email}
            onChange={(e) => update("email", e.target.value)} required placeholder="you@example.com" />

          <div className="vmn-register-grid">
            <div>
              <label htmlFor="vmn-register-password">{t("password")}</label>
              <div className="vmn-password-wrap">
                <input id="vmn-register-password" type={showPassword ? "text" : "password"}
                  autoComplete="new-password" minLength={8} value={form.password}
                  onChange={(e) => update("password", e.target.value)} required placeholder={t("minPassword")} />
                <button type="button" className="vmn-password-toggle"
                  onClick={() => setShowPassword((v) => !v)} aria-label={showPassword ? t("hidePassword") : t("showPassword")}>
                  {showPassword ? t("hidePassword") : t("showPassword")}
                </button>
              </div>
            </div>
            <div>
              <label htmlFor="vmn-confirm-password">{t("confirmPassword")}</label>
              <div className="vmn-password-wrap">
                <input id="vmn-confirm-password" type={showConfirm ? "text" : "password"}
                  autoComplete="new-password" minLength={8} value={form.passwordConfirm}
                  onChange={(e) => update("passwordConfirm", e.target.value)} required placeholder={t("confirmPassword")} />
                <button type="button" className="vmn-password-toggle"
                  onClick={() => setShowConfirm((v) => !v)} aria-label={showConfirm ? t("hidePassword") : t("showPassword")}>
                  {showConfirm ? t("hidePassword") : t("showPassword")}
                </button>
              </div>
            </div>
          </div>

          <label className="vmn-register-check">
            <input type="checkbox" checked={form.privacyPolicy}
              onChange={(e) => update("privacyPolicy", e.target.checked)} required />
            <span>{t("agreePolicy")} <AppLink href="/privacy-policy" target="_blank" rel="noreferrer">{t("privacyPolicy")}</AppLink> {t("and")} <AppLink href="/terms-of-service" target="_blank" rel="noreferrer">{t("termsOfService")}</AppLink>.</span>
          </label>

          <label className="vmn-register-check">
            <input type="checkbox" checked={form.newsletter}
              onChange={(e) => update("newsletter", e.target.checked)} />
            <span>{t("newsletterConsent")}</span>
          </label>

          {captchaSlot && <div className="vmn-captcha-slot">{captchaSlot}</div>}
          {error && <div className="vmn-login-message vmn-login-error" role="alert">{error}</div>}

          <button className="vmn-login-submit" type="submit" disabled={loading}>
            {loading ? <><span className="vmn-button-spinner" aria-hidden="true" />{t("creatingAccount")}</> : `✦  ${t("createAccount")}`}
          </button>
        </form>
      )}

      <footer className="vmn-login-footer vmn-register-footer">
        <span>{t("alreadyAccount")}</span>
        <button type="button" onClick={onLogin}>{t("login")}</button>
        <span className="vmn-footer-separator" aria-hidden="true">|</span>
        <button type="button" onClick={onHome}>{t("home")}</button>
      </footer>
    </section>
  );
}
