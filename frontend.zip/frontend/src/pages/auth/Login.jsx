import { useState } from "react";
import { useTranslation } from "../../i18n/useTranslation.js";
import "./Login.css";

export default function Login({
  onLogin, onGoogleLogin, onGoogleError, onForgotPassword, onCreateAccount, onHome,
  captchaSlot = null, loading = false, error = "",
}) {
  const { t } = useTranslation();
  const [identifier, setIdentifier] = useState("");
  const [password, setPassword] = useState("");
  const [showPassword, setShowPassword] = useState(false);

  function handleSubmit(event) {
    event.preventDefault();
    onLogin?.({ username: identifier.trim(), password });
  }

  function handleGoogleClick(event) {
    if (onGoogleLogin) return;
    event.preventDefault();
    onGoogleError?.();
  }

  return (
    <section className="vmn-auth-card vmn-login-card" aria-labelledby="vmn-login-title">
      <header className="vmn-login-brand">
        <img className="vmn-login-logo" src="/images/brand/vitamusicnote-logo.png" alt="VitaMusicNote" />
        <div className="vmn-login-brand-copy">
          <span className="vmn-login-brand-name">VitaMusicNote</span>
          <span className="vmn-login-brand-tagline">{t("brand")}</span>
        </div>
      </header>

      <div className="vmn-login-intro">
        <h1 id="vmn-login-title">{t("loginWelcome")}</h1>
        <p>{t("loginDescription")}</p>
      </div>

      <a
        className={`vmn-google-button ${onGoogleLogin ? "" : "is-disabled"}`}
        href={onGoogleLogin || undefined}
        onClick={handleGoogleClick}
        aria-disabled={onGoogleLogin ? undefined : "true"}
      >
        <span className="vmn-google-g" aria-hidden="true">G</span>
        <span>{t("continueGoogle")}</span>
      </a>

      <div className="vmn-login-divider"><span /><span>{t("orEmailPassword")}</span><span /></div>

      <form className="vmn-login-form" onSubmit={handleSubmit} aria-busy={loading}>
        <label htmlFor="vmn-identifier">{t("usernameEmail")}</label>
        <input id="vmn-identifier" name="username" type="text" autoComplete="username" data-autofocus
          placeholder={t("enterUsernameEmail")} value={identifier}
          onChange={(event) => setIdentifier(event.target.value)} required />

        <label htmlFor="vmn-password">{t("password")}</label>
        <div className="vmn-password-wrap">
          <input id="vmn-password" name="password" type={showPassword ? "text" : "password"}
            autoComplete="current-password" placeholder={t("enterPassword")} value={password}
            onChange={(event) => setPassword(event.target.value)} required />
          <button className="vmn-password-toggle" type="button" onClick={() => setShowPassword((v) => !v)}
            aria-label={showPassword ? t("hidePassword") : t("showPassword")}>
            {showPassword ? t("hidePassword") : t("showPassword")}
          </button>
        </div>

        {captchaSlot && <div className="vmn-captcha-slot">{captchaSlot}</div>}
        {error && <div className="vmn-login-message vmn-login-error" role="alert">{error}</div>}

        <button className="vmn-login-submit" type="submit" disabled={loading}>
          {loading ? <><span className="vmn-button-spinner" aria-hidden="true" />{t("signingIn")}</> : `↪  ${t("loginAction")}`}
        </button>
      </form>

      <button className="vmn-login-text-link vmn-forgot-link" type="button"
        onClick={onForgotPassword} disabled={!onForgotPassword}>
        {t("forgotPassword")}
      </button>

      <footer className="vmn-login-footer">
        <span>{t("noAccount")}</span>
        <button type="button" onClick={onCreateAccount}>{t("createAccount")}</button>
        <span className="vmn-footer-separator" aria-hidden="true">|</span>
        <button type="button" onClick={onHome}>{t("home")}</button>
      </footer>
    </section>
  );
}
