import './VStudioLoader.css'

export default function VStudioLoader({ label = 'Preparing your studio' }) {
  return (
    <div className="vstudio-loader" role="status" aria-live="polite">
      <div className="vstudio-loader-mark">
        <span className="vstudio-loader-ring" aria-hidden="true" />
        <span className="vstudio-loader-ring is-delayed" aria-hidden="true" />
        <img src="/images/brand/vitamusicnote-logo-white.png" alt="VitaMusicNote" />
      </div>
      <strong>VitaMusicNote</strong>
      <p>{label}</p>
      <span className="vstudio-loader-progress" aria-hidden="true"><i /></span>
    </div>
  )
}
