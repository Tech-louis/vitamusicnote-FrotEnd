import { useMemo } from 'react'
import {
  ArcElement,
  BarElement,
  CategoryScale,
  Chart as ChartJS,
  Filler,
  Legend,
  LineElement,
  LinearScale,
  PointElement,
  Tooltip,
} from 'chart.js'
import { Bar, Doughnut, Line } from 'react-chartjs-2'

import { useApp } from '../../state/AppContext.jsx'

ChartJS.register(
  ArcElement,
  BarElement,
  CategoryScale,
  Filler,
  Legend,
  LineElement,
  LinearScale,
  PointElement,
  Tooltip,
)

const PALETTES = {
  light: {
    text: '#5d6860',
    grid: 'rgba(8, 117, 45, 0.09)',
    tooltip: '#17221b',
  },
  dark: {
    text: '#c9d4cc',
    grid: 'rgba(255, 255, 255, 0.09)',
    tooltip: '#0b130e',
  },
}

function useChartPalette() {
  const { theme } = useApp()
  return PALETTES[theme] || PALETTES.light
}

function legendOptions(palette) {
  return {
    position: 'top',
    align: 'end',
    labels: {
      color: palette.text,
      boxWidth: 8,
      boxHeight: 8,
      usePointStyle: true,
      pointStyle: 'circle',
      font: { family: 'Inter', size: 11 },
      padding: 14,
    },
  }
}

function tooltipOptions(palette) {
  return {
    backgroundColor: palette.tooltip,
    cornerRadius: 4,
    titleFont: { family: 'Inter', size: 11 },
    bodyFont: { family: 'Inter', size: 11 },
    padding: 10,
  }
}

export function LineChart({ labels, series }) {
  const palette = useChartPalette()

  const data = useMemo(() => ({
    labels,
    datasets: series.map((item) => ({
      label: item.label,
      data: item.values,
      borderColor: item.color,
      backgroundColor: `${item.color}22`,
      borderWidth: 2,
      pointRadius: 0,
      pointHoverRadius: 4,
      tension: 0.36,
      fill: item.id === 'views' ? 'origin' : false,
      yAxisID: item.id === 'engagement' ? 'y1' : 'y',
    })),
  }), [labels, series])

  const options = useMemo(() => ({
    responsive: true,
    maintainAspectRatio: false,
    interaction: { mode: 'index', intersect: false },
    plugins: {
      legend: legendOptions(palette),
      tooltip: tooltipOptions(palette),
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { color: palette.text, maxTicksLimit: 8, font: { size: 10 } },
      },
      y: {
        beginAtZero: true,
        grid: { color: palette.grid },
        ticks: { color: palette.text, maxTicksLimit: 5, font: { size: 10 } },
      },
      y1: {
        position: 'right',
        beginAtZero: true,
        grid: { drawOnChartArea: false },
        ticks: {
          color: palette.text,
          maxTicksLimit: 5,
          font: { size: 10 },
          callback: (value) => `${value}%`,
        },
      },
    },
  }), [palette])

  return (
    <div className="vstudio-chart-canvas">
      <Line data={data} options={options} />
    </div>
  )
}

export function ViewsDownloadsChart({ data: source }) {
  const palette = useChartPalette()

  const data = useMemo(() => ({
    labels: source.labels,
    datasets: [
      {
        type: 'line',
        label: 'Views',
        data: source.views,
        borderColor: '#08752d',
        backgroundColor: '#08752d22',
        borderWidth: 2,
        pointRadius: 0,
        pointHoverRadius: 4,
        tension: 0.34,
        fill: 'origin',
        yAxisID: 'y',
      },
      {
        type: 'bar',
        label: 'Downloads',
        data: source.downloads,
        backgroundColor: 'rgba(37, 99, 235, 0.55)',
        borderColor: '#2563eb',
        borderWidth: 1,
        borderRadius: 0,
        barPercentage: 0.55,
        yAxisID: 'y1',
      },
    ],
  }), [source])

  const options = useMemo(() => ({
    responsive: true,
    maintainAspectRatio: false,
    interaction: { mode: 'index', intersect: false },
    plugins: {
      legend: legendOptions(palette),
      tooltip: tooltipOptions(palette),
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { color: palette.text, font: { size: 10 } },
      },
      y: {
        beginAtZero: true,
        grid: { color: palette.grid },
        ticks: { color: palette.text, maxTicksLimit: 5, font: { size: 10 } },
      },
      y1: {
        position: 'right',
        beginAtZero: true,
        grid: { drawOnChartArea: false },
        ticks: { color: palette.text, precision: 0, font: { size: 10 } },
      },
    },
  }), [palette])

  return (
    <div className="vstudio-chart-canvas">
      <Bar data={data} options={options} />
    </div>
  )
}

export function UploadsChart({ data: source }) {
  const palette = useChartPalette()

  const data = useMemo(() => ({
    labels: source.months,
    datasets: source.series.map((item) => ({
      label: item.label,
      data: item.values,
      backgroundColor: item.color,
      borderWidth: 0,
      borderRadius: 0,
      barPercentage: 0.82,
      categoryPercentage: 0.78,
    })),
  }), [source])

  const options = useMemo(() => ({
    responsive: true,
    maintainAspectRatio: false,
    interaction: { mode: 'index', intersect: false },
    plugins: {
      legend: legendOptions(palette),
      tooltip: tooltipOptions(palette),
    },
    scales: {
      x: {
        grid: { display: false },
        ticks: { color: palette.text, font: { size: 10 } },
      },
      y: {
        beginAtZero: true,
        grid: { color: palette.grid },
        ticks: { color: palette.text, precision: 0, font: { size: 10 } },
      },
    },
  }), [palette])

  return (
    <div className="vstudio-chart-canvas">
      <Bar data={data} options={options} />
    </div>
  )
}

export function ActionsDonut({ data }) {
  const palette = useChartPalette()
  const total = data.reduce((sum, item) => sum + item.value, 0)

  const chartData = useMemo(() => ({
    labels: data.map((item) => item.label),
    datasets: [{
      data: data.map((item) => item.value),
      backgroundColor: data.map((item) => item.color),
      borderWidth: 0,
      borderRadius: 0,
      spacing: 2,
      hoverOffset: 4,
    }],
  }), [data])

  const options = useMemo(() => ({
    responsive: true,
    maintainAspectRatio: false,
    cutout: '68%',
    plugins: {
      legend: {
        ...legendOptions(palette),
        position: 'bottom',
        align: 'center',
      },
      tooltip: {
        ...tooltipOptions(palette),
        callbacks: {
          label: (context) => {
            const value = context.parsed || 0
            const percent = total ? Math.round((value / total) * 100) : 0
            return ` ${context.label}: ${value} (${percent}%)`
          },
        },
      },
    },
  }), [palette, total])

  return (
    <div className="vstudio-donut-wrap">
      <div className="vstudio-donut">
        <Doughnut data={chartData} options={options} />
        <div className="vstudio-donut-center">
          <strong>{total}</strong>
          <span>Actions</span>
        </div>
      </div>
    </div>
  )
}
