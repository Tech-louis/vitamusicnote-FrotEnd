import Swal from 'sweetalert2'
import './vstudioAlert.css'

const studioSwal = Swal.mixin({
  customClass: {
    popup: 'vstudio-swal-popup',
    title: 'vstudio-swal-title',
    htmlContainer: 'vstudio-swal-html',
    confirmButton: 'vstudio-swal-confirm',
    cancelButton: 'vstudio-swal-cancel',
    actions: 'vstudio-swal-actions',
  },
  buttonsStyling: false,
  background: '#ffffff',
  color: '#171d19',
})

export const studioAlert = {
  success(title, text = '') {
    return studioSwal.fire({
      icon: 'success',
      iconColor: '#08752d',
      title,
      text,
      timer: 1800,
      timerProgressBar: true,
      showConfirmButton: false,
    })
  },

  error(title, text = '') {
    return studioSwal.fire({ icon: 'error', iconColor: '#dc2626', title, text })
  },

  info(title, text = '') {
    return studioSwal.fire({ icon: 'info', iconColor: '#2563eb', title, text })
  },

  async confirm(title, text = '', confirmText = 'Save changes') {
    const result = await studioSwal.fire({
      icon: 'question',
      iconColor: '#08752d',
      title,
      text,
      showCancelButton: true,
      confirmButtonText: confirmText,
      cancelButtonText: 'Cancel',
      reverseButtons: true,
      focusCancel: true,
    })
    return result.isConfirmed
  },
}

export default studioAlert
