import MaterialIcon from '../../components/common/MaterialIcon.jsx'
import {
  actionsMix,
  dashboardStats,
  recentUploads,
  studioPulse,
  topSongs,
  uploadsByType,
  viewsDownloadsSeries,
  viewsEngagementLabels,
  viewsEngagementSeries,
} from '../../data/vstudioDashboard.js'
import { ActionsDonut, LineChart, UploadsChart, ViewsDownloadsChart } from './VStudioCharts.jsx'
import './VStudioOverview.css'

export default function VStudioOverview() {
  const maxTopSongViews = Math.max(...topSongs.map((song) => song.views), 1)

  return (
    <div className="vstudio-dashboard">
      <section className="vstudio-stat-grid" id="stats" aria-label="Studio statistics">
        {dashboardStats.map((stat) => (
          <article className="vstudio-stat-card animate__animated animate__fadeInUp" key={stat.id}>
            <div className="vstudio-stat-head">
              <span className="vstudio-stat-icon"><MaterialIcon name={stat.icon} size={19} /></span>
              <span className="vstudio-stat-change">{stat.change}</span>
            </div>
            <strong>{stat.value}</strong>
            <span className="vstudio-stat-label">{stat.label}</span>
            {stat.note && <small>{stat.note}</small>}
          </article>
        ))}
      </section>

      <div className="vstudio-dashboard-grid">
        <section className="vstudio-card is-wide animate__animated animate__fadeInUp">
          <header className="vstudio-card-head">
            <h2>Views &amp; engagement</h2>
            <small>Click legend to show/hide</small>
          </header>
          <LineChart labels={viewsEngagementLabels} series={viewsEngagementSeries} />
        </section>

        <section className="vstudio-card animate__animated animate__fadeInUp">
          <header className="vstudio-card-head">
            <h2>Studio pulse</h2>
          </header>
          <div className="vstudio-pulse-grid">
            {studioPulse.map((item) => (
              <div className="vstudio-pulse-item" key={item.label}>
                <span>{item.label}</span>
                <strong>{item.value}</strong>
                {item.note && <small>{item.note}</small>}
              </div>
            ))}
          </div>
          <div className="vstudio-top-songs">
            <h3>Top 5 songs · Views (48h)</h3>
            <ol>
              {topSongs.map((song, index) => (
                <li key={song.title}>
                  <span className="vstudio-song-rank">{index + 1}</span>
                  <div className="vstudio-song-bar">
                    <span className="vstudio-song-title">{song.title}</span>
                    <span className="vstudio-song-track">
                      <span style={{ width: `${(song.views / maxTopSongViews) * 100}%` }} />
                    </span>
                  </div>
                  <strong>{song.views}</strong>
                </li>
              ))}
            </ol>
          </div>
        </section>

        <section className="vstudio-card is-wide animate__animated animate__fadeInUp" id="content">
          <header className="vstudio-card-head">
            <h2>Views &amp; Downloads — last 21 days</h2>
            <small>21d</small>
          </header>
          <ViewsDownloadsChart data={viewsDownloadsSeries} />
        </section>

        <section className="vstudio-card animate__animated animate__fadeInUp" id="review">
          <header className="vstudio-card-head">
            <h2>Actions mix (21d)</h2>
          </header>
          <ActionsDonut data={actionsMix} />
        </section>

        <section className="vstudio-card is-wide animate__animated animate__fadeInUp">
          <header className="vstudio-card-head">
            <h2>Uploads by file type</h2>
            <small>12 months • click legend</small>
          </header>
          <UploadsChart data={uploadsByType} />
        </section>

        <section className="vstudio-card animate__animated animate__fadeInUp" id="uploads">
          <header className="vstudio-card-head">
            <h2>Recent uploads (5)</h2>
          </header>
          <ul className="vstudio-upload-list">
            {recentUploads.map((upload) => (
              <li key={upload.title}>
                <span className="vstudio-upload-icon"><MaterialIcon name="music_note" size={17} /></span>
                <div>
                  <strong>{upload.title}</strong>
                  <span>{upload.type} · {upload.date}</span>
                </div>
                <span className="vstudio-status">{upload.status}</span>
              </li>
            ))}
          </ul>
        </section>
      </div>
    </div>
  )
}
