import { useState } from 'react'

import MaterialIcon from '../../components/common/MaterialIcon.jsx'
import { useApp } from '../../state/AppContext.jsx'
import studioAlert from './vstudioAlert.js'
import './VStudioSettings.css'

const SETTINGS_KEY = 'vitamusicnote-vstudio-settings'
const DEFAULT_PREFS = {
  emailNotifications: true,
  pushNotifications: false,
  newsletter: false,
  publicProfile: true,
  activityStatus: true,
}

function readPrefs() {
  try {
    const saved = JSON.parse(localStorage.getItem(SETTINGS_KEY) || 'null')
    return saved && typeof saved === 'object' ? { ...DEFAULT_PREFS, ...saved } : DEFAULT_PREFS
  } catch {
    return DEFAULT_PREFS
  }
}

function ToggleRow({ icon, title, description, checked, onChange }) {
  return (
    <label className="vstudio-toggle-row">
      <span className="vstudio-toggle-icon"><MaterialIcon name={icon} size={18} /></span>
      <span className="vstudio-toggle-copy">
        <strong>{title}</strong>
        <small>{description}</small>
      </span>
      <input type="checkbox" checked={checked} onChange={(event) => onChange(event.target.checked)} />
      <span className="vstudio-toggle-switch" aria-hidden="true" />
    </label>
  )
}

export default function VStudioSettings() {
  const { theme, setTheme, fontScale, setFontScale, highContrast, setHighContrast, handleLogout } = useApp()
  const [prefs, setPrefs] = useState(readPrefs)

  function toggle(key) {
    setPrefs((current) => ({ ...current, [key]: !current[key] }))
  }

  function save(event) {
    event.preventDefault()
    try {
      localStorage.setItem(SETTINGS_KEY, JSON.stringify(prefs))
      studioAlert.success('Settings saved', 'Your studio preferences were updated.')
    } catch {
      studioAlert.error('Could not save settings', 'Please try again in a moment.')
    }
  }

  async function reset() {
    const confirmed = await studioAlert.confirm(
      'Reset all preferences?',
      'Appearance, notifications and privacy options will return to their defaults.',
      'Reset settings',
    )
    if (!confirmed) return
    try {
      localStorage.removeItem(SETTINGS_KEY)
      setPrefs(DEFAULT_PREFS)
      setTheme('light')
      setFontScale(1)
      setHighContrast(false)
      studioAlert.success('Settings reset', 'Your studio preferences are back to defaults.')
    } catch {
      studioAlert.error('Could not reset settings', 'Please try again in a moment.')
    }
  }

  async function logout() {
    const confirmed = await studioAlert.confirm('Log out of VStudio?', 'You will need to sign in again to personalize your studio.', 'Log out')
    if (!confirmed) return
    await handleLogout()
  }

  return (
    <form className="vstudio-settings" onSubmit={save}>
      <section className="vstudio-settings-intro animate__animated animate__fadeInUp">
        <div>
          <p className="vstudio-settings-eyebrow">Mipangilio</p>
          <h2>Make the studio yours</h2>
          <p>Control how VStudio looks, what you see, and how VitaMusicNote keeps you updated.</p>
        </div>
        <div className="vstudio-settings-actions">
          <button type="button" className="vstudio-button is-ghost" onClick={reset}>Reset defaults</button>
          <button type="submit" className="vstudio-button is-primary"><MaterialIcon name="save" size={16} /> Save settings</button>
        </div>
      </section>

      <div className="vstudio-settings-grid">
        <section className="vstudio-settings-panel animate__animated animate__fadeInUp">
          <header className="vstudio-panel-head">
            <h2>Appearance</h2>
            <span>Display &amp; readability</span>
          </header>

          <div className="vstudio-setting-block">
            <span className="vstudio-setting-label">Theme</span>
            <div className="vstudio-segmented">
              <button
                type="button"
                className={theme === 'light' ? 'is-active' : ''}
                onClick={() => setTheme('light')}
                aria-pressed={theme === 'light'}
              >
                <MaterialIcon name="light_mode" size={16} /> Light
              </button>
              <button
                type="button"
                className={theme === 'dark' ? 'is-active' : ''}
                onClick={() => setTheme('dark')}
                aria-pressed={theme === 'dark'}
              >
                <MaterialIcon name="dark_mode" size={16} /> Dark
              </button>
            </div>
          </div>

          <div className="vstudio-setting-block">
            <div className="vstudio-setting-row">
              <span className="vstudio-setting-label">Text size</span>
              <strong>{Math.round(fontScale * 100)}%</strong>
            </div>
            <input
              type="range"
              min="0.9"
              max="1.2"
              step="0.05"
              value={fontScale}
              onChange={(event) => setFontScale(Number(event.target.value))}
              aria-label="Text size"
            />
            <div className="vstudio-range-scale"><span>Small</span><span>Default</span><span>Large</span></div>
          </div>

          <ToggleRow
            icon="contrast"
            title="High contrast"
            description="Stronger borders and clearer focus states"
            checked={highContrast}
            onChange={setHighContrast}
          />
        </section>

        <section className="vstudio-settings-panel animate__animated animate__fadeInUp">
          <header className="vstudio-panel-head">
            <h2>Notifications</h2>
            <span>What you hear about</span>
          </header>
          <div className="vstudio-toggle-list">
            <ToggleRow
              icon="mail"
              title="Email notifications"
              description="Important account and studio activity"
              checked={prefs.emailNotifications}
              onChange={() => toggle('emailNotifications')}
            />
            <ToggleRow
              icon="notifications"
              title="Push notifications"
              description="New uploads, likes and downloads"
              checked={prefs.pushNotifications}
              onChange={() => toggle('pushNotifications')}
            />
            <ToggleRow
              icon="campaign"
              title="Community newsletter"
              description="Monthly music and ministry highlights"
              checked={prefs.newsletter}
              onChange={() => toggle('newsletter')}
            />
          </div>
        </section>

        <section className="vstudio-settings-panel animate__animated animate__fadeInUp">
          <header className="vstudio-panel-head">
            <h2>Privacy</h2>
            <span>Your public presence</span>
          </header>
          <div className="vstudio-toggle-list">
            <ToggleRow
              icon="public"
              title="Public profile"
              description="Let others see your profile and uploaded songs"
              checked={prefs.publicProfile}
              onChange={() => toggle('publicProfile')}
            />
            <ToggleRow
              icon="visibility"
              title="Activity status"
              description="Show when you are active in the studio"
              checked={prefs.activityStatus}
              onChange={() => toggle('activityStatus')}
            />
          </div>
          <div className="vstudio-settings-note">
            <MaterialIcon name="language" size={17} />
            <span>Language is managed from the switcher in the top header.</span>
          </div>
        </section>

        <section className="vstudio-settings-panel is-danger animate__animated animate__fadeInUp">
          <header className="vstudio-panel-head">
            <h2>Session</h2>
            <span>Account access</span>
          </header>
          <p>Logging out ends this device session. You can sign in again any time.</p>
          <button type="button" className="vstudio-button is-danger" onClick={logout}>
            <MaterialIcon name="logout" size={16} /> Log out
          </button>
        </section>
      </div>
    </form>
  )
}
