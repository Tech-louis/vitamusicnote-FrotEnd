import { useRef, useState } from 'react'

import MaterialIcon from '../../components/common/MaterialIcon.jsx'
import { useApp } from '../../state/AppContext.jsx'
import { getProfilePhoto, handleAvatarError } from '../../data/profile.js'
import { dashboardProfile } from '../../data/vstudioDashboard.js'
import studioAlert from './vstudioAlert.js'
import './VStudioProfile.css'

const PROFILE_KEY = 'vitamusicnote-vstudio-profile'

function readProfile(user) {
  const base = {
    first_name: user?.first_name || '',
    last_name: user?.last_name || '',
    email: user?.email || '',
    phone: '',
    location: '',
    website: '',
    bio: '',
  }
  try {
    const saved = JSON.parse(localStorage.getItem(PROFILE_KEY) || 'null')
    return saved && typeof saved === 'object' ? { ...base, ...saved } : base
  } catch {
    return base
  }
}

export default function VStudioProfile() {
  const { user, updateUser } = useApp()
  const fileRef = useRef(null)
  const [form, setForm] = useState(() => readProfile(user))
  const [photo, setPhoto] = useState(() => user?.photo || '')

  const name = [form.first_name, form.last_name].filter(Boolean).join(' ')
    || user?.email?.split('@')[0]
    || dashboardProfile.fallbackName

  function update(field, value) {
    setForm((current) => ({ ...current, [field]: value }))
  }

  function choosePhoto(event) {
    const file = event.target.files?.[0]
    if (!file) return
    if (!file.type.startsWith('image/')) {
      studioAlert.error('Invalid image', 'Please choose a PNG, JPG or WEBP file.')
      return
    }
    if (file.size > 2 * 1024 * 1024) {
      studioAlert.error('Image too large', 'Profile photos must be smaller than 2 MB.')
      return
    }
    const reader = new FileReader()
    reader.onload = () => setPhoto(String(reader.result))
    reader.readAsDataURL(file)
  }

  async function removePhoto() {
    const confirmed = await studioAlert.confirm(
      'Remove profile photo?',
      'Your default VitaMusicNote avatar will be restored.',
      'Remove photo',
    )
    if (!confirmed) return
    setPhoto('')
    if (fileRef.current) fileRef.current.value = ''
    updateUser?.({ photo: '' })
    studioAlert.success('Photo removed', 'Your default avatar is now active.')
  }

  function saveProfile(event) {
    event.preventDefault()
    const changes = { first_name: form.first_name.trim(), last_name: form.last_name.trim() }
    const payload = { ...form, ...changes, photo }
    try {
      localStorage.setItem(PROFILE_KEY, JSON.stringify(payload))
      updateUser?.({ ...changes, photo })
      studioAlert.success('Profile saved', 'Your studio profile has been updated.')
    } catch {
      studioAlert.error('Could not save profile', 'Please try again in a moment.')
    }
  }

  async function changePassword() {
    const confirmed = await studioAlert.confirm(
      'Send password reset link?',
      'We will send a secure reset link to your account email address.',
      'Send link',
    )
    if (confirmed) studioAlert.success('Reset link sent', 'Check your inbox to continue.')
  }

  function toggleTwoFactor() {
    studioAlert.info(
      'Two-factor authentication',
      'Two-factor setup will be available when account security is connected.',
    )
  }

  return (
    <div className="vstudio-profile">
      <section className="vstudio-profile-hero animate__animated animate__fadeInUp">
        <div className="vstudio-profile-avatar-wrap">
          <img src={getProfilePhoto(photo)} alt="" onError={handleAvatarError} />
          <button type="button" onClick={() => fileRef.current?.click()} aria-label="Change profile photo">
            <MaterialIcon name="photo_camera" size={18} />
          </button>
          <input ref={fileRef} type="file" accept="image/*" onChange={choosePhoto} hidden />
        </div>
        <div className="vstudio-profile-identity">
          <p className="vstudio-profile-eyebrow">Wasifu</p>
          <h2>{name}</h2>
          <p>{form.email || user?.email || 'No email on this device'}</p>
          <div className="vstudio-profile-badges">
            <span><MaterialIcon name="verified" size={14} /> Active account</span>
            <span><MaterialIcon name="calendar_month" size={14} /> {user?.date_joined ? new Date(user.date_joined).toLocaleDateString() : 'Member'}</span>
          </div>
        </div>
        <div className="vstudio-profile-actions">
          <button type="button" className="vstudio-button is-outline" onClick={() => fileRef.current?.click()}>
            <MaterialIcon name="upload" size={16} /> Change photo
          </button>
          <button type="button" className="vstudio-button is-ghost" onClick={removePhoto}>
            <MaterialIcon name="delete_outline" size={16} /> Remove
          </button>
        </div>
      </section>

      <div className="vstudio-profile-grid">
        <form className="vstudio-profile-panel animate__animated animate__fadeInUp" onSubmit={saveProfile}>
          <header className="vstudio-panel-head">
            <h2>Personal details</h2>
            <span>Visible to your account</span>
          </header>
          <div className="vstudio-field-grid">
            <label className="vstudio-field">
              <span>First name</span>
              <input value={form.first_name} onChange={(event) => update('first_name', event.target.value)} placeholder="Louis" />
            </label>
            <label className="vstudio-field">
              <span>Last name</span>
              <input value={form.last_name} onChange={(event) => update('last_name', event.target.value)} placeholder="Salvatory" />
            </label>
            <label className="vstudio-field">
              <span>Email address</span>
              <input type="email" value={form.email} readOnly aria-readonly="true" placeholder="you@example.com" />
            </label>
            <label className="vstudio-field">
              <span>Phone number</span>
              <input value={form.phone} onChange={(event) => update('phone', event.target.value)} placeholder="+255 700 000 000" />
            </label>
            <label className="vstudio-field">
              <span>Location</span>
              <input value={form.location} onChange={(event) => update('location', event.target.value)} placeholder="Dar es Salaam, Tanzania" />
            </label>
            <label className="vstudio-field">
              <span>Website</span>
              <input value={form.website} onChange={(event) => update('website', event.target.value)} placeholder="vitamusicnote.com" />
            </label>
          </div>
          <label className="vstudio-field">
            <span>About</span>
            <textarea value={form.bio} onChange={(event) => update('bio', event.target.value)} rows="4" placeholder="Tell the community about your music and ministry..." />
          </label>
          <div className="vstudio-panel-actions">
            <button type="submit" className="vstudio-button is-primary"><MaterialIcon name="save" size={16} /> Save changes</button>
          </div>
        </form>

        <aside className="vstudio-profile-side">
          <section className="vstudio-profile-panel animate__animated animate__fadeInUp">
            <header className="vstudio-panel-head"><h2>Account details</h2></header>
            <dl className="vstudio-detail-list">
              <div><dt>Username</dt><dd>{form.email?.split('@')[0] || 'louis'}</dd></div>
              <div><dt>Email verified</dt><dd><span className="vstudio-status">Verified</span></dd></div>
              <div><dt>Language</dt><dd>Kiswahili</dd></div>
              <div><dt>Account status</dt><dd>Active</dd></div>
            </dl>
          </section>

          <section className="vstudio-profile-panel animate__animated animate__fadeInUp">
            <header className="vstudio-panel-head"><h2>Security</h2></header>
            <div className="vstudio-security-list">
              <button type="button" onClick={changePassword}>
                <MaterialIcon name="lock" size={18} />
                <span><strong>Change password</strong><small>Send a secure reset link to your email</small></span>
                <MaterialIcon name="chevron_right" size={17} />
              </button>
              <button type="button" onClick={toggleTwoFactor}>
                <MaterialIcon name="shield" size={18} />
                <span><strong>Two-factor authentication</strong><small>Add an extra layer of protection</small></span>
                <MaterialIcon name="chevron_right" size={17} />
              </button>
            </div>
          </section>
        </aside>
      </div>
    </div>
  )
}
