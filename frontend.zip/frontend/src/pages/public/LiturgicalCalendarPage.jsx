import { useCallback, useEffect, useMemo, useState } from "react";
import { useNavigate, useSearch } from "@tanstack/react-router";

import MaterialIcon from "../../components/common/MaterialIcon.jsx";
import Modal from "../../components/common/Modal.jsx";
import calendar from "../../data/liturgicalCalendar.json";
import { useTranslation } from "../../i18n/useTranslation.js";
import "./PageHero.css";
import "./LiturgicalCalendarPage.css";

const CYCLES = ["A", "B", "C"];

function sectionText(value, cycle) {
  if (typeof value === "string") return value;
  if (!value || typeof value !== "object") return "";
  if (value[cycle]) return value[cycle];
  if (value.text) return value.text;
  return CYCLES.map((key) => value[key]).find(Boolean) || "";
}

function haystackFor(celebration) {
  const values = Object.values(celebration.sections).flatMap((value) =>
    typeof value === "string" ? [value] : Object.values(value || {}),
  );
  return [celebration.name, ...values].join(" ").toLowerCase();
}

const allCelebrations = calendar.seasons.flatMap((season) =>
  season.celebrations.map((celebration) => ({
    ...celebration,
    seasonId: season.id,
    seasonName: season.name,
    haystack: haystackFor(celebration),
  })),
);

export default function LiturgicalCalendarPage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const search = useSearch({ from: "/liturgical-calendar" });

  const season = search.season || "";
  const cycle = search.cycle || "A";
  const query = search.q || "";
  const view = search.view || "list";

  const [selected, setSelected] = useState(null);
  const [copiedKey, setCopiedKey] = useState("");
  const [filtersOpen, setFiltersOpen] = useState(false);

  const closeModal = useCallback(() => setSelected(null), []);
  const [showBackToTop, setShowBackToTop] = useState(false);

  useEffect(() => {
    const onScroll = () => setShowBackToTop(window.scrollY > 320);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  const activeFilterCount = (season ? 1 : 0) + (cycle !== "A" ? 1 : 0) + (query ? 1 : 0);

  function updateSearch(next) {
    const values = {
      season: next.season ?? season,
      cycle: next.cycle ?? cycle,
      q: next.q ?? query,
      view: next.view ?? view,
    };

    navigate({
      to: "/liturgical-calendar",
      search: {
        ...(values.season ? { season: values.season } : {}),
        ...(values.cycle !== "A" ? { cycle: values.cycle } : {}),
        ...(values.view === "grid" ? { view: "grid" } : {}),
        ...(values.q ? { q: values.q } : {}),
      },
      replace: true,
    });
  }

  function resetFilters() {
    updateSearch({ season: "", cycle: "A", q: "" });
  }

  function scrollToTop() {
    const reduceMotion = window.matchMedia?.("(prefers-reduced-motion: reduce)")?.matches;
    window.scrollTo({ top: 0, behavior: reduceMotion ? "auto" : "smooth" });
  }

  const activeSeason = calendar.seasons.find((item) => item.id === season) || null;
  const terms = useMemo(() => query.trim().toLowerCase().split(/\s+/).filter(Boolean), [query]);

  const visible = useMemo(
    () =>
      allCelebrations.filter(
        (item) =>
          (!activeSeason || item.seasonId === activeSeason.id) &&
          terms.every((term) => item.haystack.includes(term)),
      ),
    [activeSeason, terms],
  );

  function sectionLabel(key) {
    return t(`calendarSection_${key}`, calendar.sectionLabels[key] || key);
  }

  async function copyText(key, value) {
    if (!value || typeof navigator === "undefined" || !navigator.clipboard) return;

    try {
      await navigator.clipboard.writeText(value);
      setCopiedKey(key);
      window.setTimeout(() => {
        setCopiedKey((current) => (current === key ? "" : current));
      }, 1600);
    } catch {
      // Clipboard access can be blocked by the browser; ignore and keep the text visible.
    }
  }

  return (
    <div className="vmn-calendar-page">
      <header className="vmn-page-hero">
        <p className="eyebrow">VITAMUSICNOTE</p>
        <h1>{t("liturgicalCalendar")}</h1>
        <p>{t("liturgicalCalendarIntro")}</p>
      </header>

      <form className="calendar-search" role="search" onSubmit={(event) => event.preventDefault()}>
        <MaterialIcon name="search" size={22} />
        <span className="sr-only">{t("calendarSearchPlaceholder")}</span>
        <input
          type="search"
          value={query}
          onChange={(event) => updateSearch({ q: event.target.value })}
          placeholder={t("calendarSearchPlaceholder")}
          aria-label={t("calendarSearchPlaceholder")}
        />
        {query && (
          <button type="button" onClick={() => updateSearch({ q: "" })} aria-label={t("calendarClearSearch")}>
            <MaterialIcon name="close" size={20} />
          </button>
        )}
      </form>

      <div className="calendar-filter-bar">
        <button
          type="button"
          className={`calendar-filter-toggle ${filtersOpen ? "is-open" : ""}`}
          aria-expanded={filtersOpen}
          aria-controls="calendar-filter-panel"
          onClick={() => setFiltersOpen((open) => !open)}
        >
          <MaterialIcon name="tune" size={18} />
          <span>{t("calendarFilters")}</span>
          {activeFilterCount > 0 && <span className="calendar-filter-count">{activeFilterCount}</span>}
          <MaterialIcon name={filtersOpen ? "expand_less" : "expand_more"} size={18} />
        </button>
        {activeFilterCount > 0 && (
          <button type="button" className="calendar-filter-reset" onClick={resetFilters}>
            {t("calendarResetFilters")}
          </button>
        )}
      </div>

      {filtersOpen && (
        <div className="calendar-filter-panel" id="calendar-filter-panel">
          <div className="calendar-control-group">
            <span className="calendar-control-label">{t("calendarSeason")}</span>
            <div className="calendar-chips" role="group" aria-label={t("calendarSeason")}>
              <button
                type="button"
                className={`calendar-chip animate__animated animate__fadeInUp ${season ? "" : "is-active"}`}
                aria-pressed={!season}
                onClick={() => {
                  updateSearch({ season: "" });
                }}
              >
                {t("calendarAllSeasons")}
              </button>
              {calendar.seasons.map((item) => (
                <button
                  key={item.id}
                  type="button"
                  className={`calendar-chip animate__animated animate__fadeInUp ${season === item.id ? "is-active" : ""}`}
                  aria-pressed={season === item.id}
                  onClick={() => {
                    updateSearch({ season: item.id });
                  }}
                >
                  {item.name}
                </button>
              ))}
            </div>
          </div>

          <div className="calendar-control-group">
            <span className="calendar-control-label">{t("calendarCycle")}</span>
            <div className="calendar-cycles" role="group" aria-label={t("calendarCycle")}>
              {CYCLES.map((item) => (
                <button
                  key={item}
                  type="button"
                  className={`calendar-cycle animate__animated animate__fadeInUp ${cycle === item ? "is-active" : ""}`}
                  aria-pressed={cycle === item}
                  onClick={() => updateSearch({ cycle: item })}
                >
                  {item}
                </button>
              ))}
            </div>
          </div>

          <p className="calendar-cycle-note">{t("calendarCycleNote")}</p>
        </div>
      )}

      <div className="calendar-results-head">
        <h2>{t("calendarCelebrations")}</h2>
        <span>{visible.length}</span>
        <div className="calendar-view-toggle" role="group" aria-label={t("calendarView")}>
          <button
            type="button"
            className={view === "list" ? "is-active" : ""}
            aria-pressed={view === "list"}
            aria-label={t("calendarViewList")}
            onClick={() => updateSearch({ view: "list" })}
          >
            <MaterialIcon name="view_list" size={18} />
          </button>
          <button
            type="button"
            className={view === "grid" ? "is-active" : ""}
            aria-pressed={view === "grid"}
            aria-label={t("calendarViewGrid")}
            onClick={() => updateSearch({ view: "grid" })}
          >
            <MaterialIcon name="grid_view" size={18} />
          </button>
        </div>
      </div>

      {visible.length ? (
        <div className={`${view === "grid" ? "calendar-grid" : "calendar-list"}`}>
          {visible.map((item) => (
            <article className="calendar-card animate__animated animate__fadeInUp" key={item.id}>
              <button
                type="button"
                className="calendar-card-toggle"
                aria-label={`${t("calendarOpen")}: ${item.name}`}
                onClick={() => setSelected(item)}
              >
                <span className="calendar-card-main">
                  <span className="calendar-card-season">{item.seasonName}</span>
                  <strong>{item.name}</strong>
                </span>
                <span className="calendar-card-meta">
                  <span>{Object.keys(item.sections).length}</span>
                  <MaterialIcon name="open_in_full" size={18} />
                </span>
              </button>
            </article>
          ))}
        </div>
      ) : (
        <div className="calendar-empty">
          <MaterialIcon name="search_off" size={30} />
          <p>{t("calendarNoResults")}</p>
        </div>
      )}

      <Modal open={Boolean(selected)} title={selected?.name || t("calendarDetails")} onClose={closeModal}>
        {selected && (
          <div className="calendar-modal-content">
            <span className="calendar-card-season">{selected.seasonName}</span>
            <h2>{selected.name}</h2>
            <div className="calendar-modal-texts">
              {Object.entries(selected.sections).map(([key, value]) => {
                const text = sectionText(value, cycle);
                if (!text) return null;

                const copyKey = `${selected.id}:${key}`;
                const isVariant = typeof value === "object" && Boolean(value[cycle]);

                return (
                  <section className="calendar-text animate__animated animate__fadeInUp" key={key}>
                    <div className="calendar-text-head">
                      <h3>
                        {sectionLabel(key)}
                        {isVariant && <span className="calendar-text-cycle">{cycle}</span>}
                      </h3>
                      <button
                        type="button"
                        onClick={() => copyText(copyKey, text)}
                        aria-label={t(copiedKey === copyKey ? "calendarCopied" : "calendarCopy")}
                      >
                        <MaterialIcon
                          name={copiedKey === copyKey ? "check" : "content_copy"}
                          size={16}
                        />
                        <span>{t(copiedKey === copyKey ? "calendarCopied" : "calendarCopy")}</span>
                      </button>
                    </div>
                    <p>{text}</p>
                  </section>
                );
              })}
            </div>
          </div>
        )}
      </Modal>

      {showBackToTop && (
        <button
          type="button"
          className="calendar-back-to-top"
          onClick={scrollToTop}
          aria-label={t("backToTop")}
          title={t("backToTop")}
        >
          <MaterialIcon name="arrow_upward" size={20} />
        </button>
      )}
    </div>
  );
}
