import { useCallback, useEffect, useMemo, useState } from "react";
import AppLink from "../../components/common/AppLink.jsx";
import SearchBar from "../../components/common/SearchBar.jsx";
import MusicCard from "../../components/common/MusicCard.jsx";
import MaterialIcon from "../../components/common/MaterialIcon.jsx";
import { MusicCardSkeleton } from "../../components/common/LoadingExperience.jsx";
import { categories, recentPublishedSongs, songs, statistics } from "../../data/music.js";
import { composers } from "../../data/composers.js";
import { contributors } from "../../data/contributors.js";
import { getProfilePhoto, handleAvatarError } from "../../data/profile.js";
import { useTranslation } from "../../i18n/useTranslation.js";
import { useApp } from "../../state/AppContext.jsx";
import "./HomePage.css";

const ALL = "all";

const CATEGORY_ALIASES = {
  Misa: ["Mass Setting", "Mass Settings"],
  Sifa: ["Hymn", "Hymns"],
  Zaburi: ["Psalm", "Psalms"],
  Anthem: ["Anthem", "Anthems"],
  "Mafundisho/Tafakari": ["Prayer Song"],
};

function categoryMatches(categoryName, song) {
  const aliases = CATEGORY_ALIASES[categoryName] || [categoryName];
  return aliases.includes(song.category);
}

function Hero({ t }) {
  return (
    <section className="vmn-home-hero" id="top">
      <div className="vmn-home-hero-copy">
        <p className="vmn-home-eyebrow">
          <MaterialIcon name="auto_awesome" size={17} />
          {t("eyebrow")}
        </p>
        <h1>
          {t("heroTitle")}
          <span>{t("heroSecond")}</span>
        </h1>
        <p className="vmn-home-lead">{t("heroDesc")}</p>

        <div className="vmn-home-actions">
          <AppLink href="#categories" className="vmn-home-primary">
            <MaterialIcon name="explore" size={20} />
            {t("exploreMusic")}
          </AppLink>
        </div>

        <ul className="vmn-home-proof" aria-label={t("highlights", "Highlights")}>
          <li className="animate__animated animate__fadeInUp"><MaterialIcon name="check_circle" size={16} /> {t("organizedLibrary", "Organized library")}</li>
          <li className="animate__animated animate__fadeInUp"><MaterialIcon name="download" size={16} /> {t("download", "Download")}</li>
          <li className="animate__animated animate__fadeInUp"><MaterialIcon name="groups" size={16} /> {t("choirs", "For choirs")}</li>
        </ul>
      </div>

      <div className="vmn-home-hero-art" aria-hidden="true">
        <div className="vmn-home-art-glow" />
        <div className="vmn-home-sheet">
          <span className="vmn-home-sheet-note">𝄞</span>
          <div className="vmn-home-sheet-lines">
            {[82, 64, 91, 48, 76, 58, 88].map((width, index) => (
              <span key={index} style={{ width: `${width}%` }} />
            ))}
          </div>
          <div className="vmn-home-sheet-tag"><MaterialIcon name="music_note" size={15} /> SATB · {t("choral", "Choral")}</div>
        </div>
        <div className="vmn-home-float vmn-home-float-top"><MaterialIcon name="star" size={16} /> 4.9</div>
        <div className="vmn-home-float vmn-home-float-bottom"><MaterialIcon name="headphones" size={16} /> {t("preview", "Preview")}</div>
      </div>
    </section>
  );
}

function RecentPublishingTicker({ t }) {
  const [activeIndex, setActiveIndex] = useState(0);

  useEffect(() => {
    if (recentPublishedSongs.length < 2) return undefined;
    const interval = window.setInterval(() => {
      setActiveIndex((current) => (current + 1) % recentPublishedSongs.length);
    }, 4500);
    return () => window.clearInterval(interval);
  }, []);

  const item = recentPublishedSongs[activeIndex];
  if (!item) return null;

  return (
    <section className="vmn-recent-publishing" aria-live="polite" aria-atomic="true">
      <span className="vmn-recent-live-dot" />
      <strong className="vmn-recent-label">{t("recentlyPublished", "Recently published")}</strong>
      <span className="vmn-recent-divider">·</span>
      <span className="vmn-recent-song" key={item.id}>
        <strong>{item.title}</strong>
        <span>{t("by", "by")} {item.composer}</span>
        <small>{item.category}</small>
      </span>
      <span className="vmn-recent-counter">{activeIndex + 1}/{recentPublishedSongs.length}</span>
    </section>
  );
}

function NextSunday({ t }) {
  return (
    <section className="vmn-home-sunday" id="next-sunday">
      <div className="vmn-home-sunday-icon"><MaterialIcon name="calendar_month" size={30} /></div>
      <div className="vmn-home-sunday-copy">
        <p>{t("nextMusic")}</p>
        <strong>22 Nov 2026</strong>
        <span>– Dominica XXXIV (Christ the King)</span>
      </div>
      <AppLink href="#featured" className="vmn-home-sunday-link">
        {t("viewMusic")} <MaterialIcon name="arrow_forward" size={19} />
      </AppLink>
    </section>
  );
}

function CategoryFilter({ t, activeCategory, onChange }) {
  const totalSongs = categories.reduce((total, category) => total + category.songCount, 0);

  return (
    <div className="vmn-home-filters" role="group" aria-label={t("browseCategory")}>
      <button
        type="button"
        onClick={() => onChange(ALL)}
        className={`animate__animated animate__fadeInUp ${activeCategory === ALL ? "is-active" : ""}`.trim()}
        aria-pressed={activeCategory === ALL}
      >
        {t("viewAll")}
        <span>{totalSongs.toLocaleString()}</span>
      </button>
      {categories.map((category) => {
        const active = activeCategory === category.name;
        return (
          <button
            key={category.name}
            type="button"
            onClick={() => onChange(category.name)}
            className={`animate__animated animate__fadeInUp ${active ? "is-active" : ""}`.trim()}
            aria-pressed={active}
          >
            <MaterialIcon name={category.icon} size={18} />
            {(t("category") && typeof t("category") === "object" && t("category")[category.name]) || category.name}
            <span>{category.songCount.toLocaleString()}</span>
          </button>
        );
      })}
    </div>
  );
}

function FeaturedMusic({ t, loading, activeCategory, onClearFilter, activePreviewId, onPreviewPlay }) {
  const visibleSongs = useMemo(
    () => activeCategory === ALL ? songs : songs.filter((song) => categoryMatches(activeCategory, song)),
    [activeCategory]
  );
  const categoryDictionary = t("category");
  const categoryLabel = categoryDictionary && typeof categoryDictionary === "object"
    ? categoryDictionary[activeCategory] || activeCategory
    : activeCategory;

  return (
    <section className="vmn-home-section" id="featured">
      <div className="vmn-home-section-heading">
        <div>
          <p className="vmn-home-section-kicker">{t("featured")}</p>
          <h2>{activeCategory === ALL ? t("featured") : categoryLabel}</h2>
        </div>
        {activeCategory !== ALL ? (
          <button type="button" onClick={onClearFilter} className="vmn-home-text-link">
            {t("clearFilter", "Clear filter")} <MaterialIcon name="arrow_forward" size={18} />
          </button>
        ) : (
          <AppLink href="/search" className="vmn-home-text-link">
            {t("viewAll")} <MaterialIcon name="arrow_forward" size={18} />
          </AppLink>
        )}
      </div>

      {loading ? (
        <div className="vmn-home-grid"><MusicCardSkeleton count={3} /></div>
      ) : visibleSongs.length ? (
        <div className="vmn-home-grid">
          {visibleSongs.map((song) => (
            <MusicCard
              key={song.id}
              song={song}
              t={t}
              onPreviewPlay={onPreviewPlay}
              activePreviewId={activePreviewId}
            />
          ))}
        </div>
      ) : (
        <div className="vmn-home-empty">
          <MaterialIcon name="menu_book" size={28} />
          <p>{t("noResults")}</p>
          <button type="button" onClick={onClearFilter} className="vmn-home-secondary">
            {t("viewAll")}
          </button>
        </div>
      )}
    </section>
  );
}

function ComposerSpotlight({ t }) {
  return (
    <section className="vmn-home-section" aria-label={t("composers")}>
      <div className="vmn-home-section-heading">
        <div>
          <p className="vmn-home-section-kicker">{t("community", "Community")}</p>
          <h2>{t("composers")}</h2>
        </div>
        <AppLink href="/composers" className="vmn-home-text-link">
          {t("viewAll")} <MaterialIcon name="arrow_forward" size={18} />
        </AppLink>
      </div>

      <div className="vmn-home-composers">
        {composers.slice(0, 3).map((composer) => (
          <AppLink href="/composers" className="vmn-home-composer animate__animated animate__fadeInUp" key={composer.id}>
            <img className="vmn-home-composer-avatar" src={getProfilePhoto(composer.photo)} alt="" onError={handleAvatarError} />
            <span className="vmn-home-composer-body">
              <strong>{composer.name}</strong>
              <small>{composer.focus}</small>
              <span>{composer.location}</span>
            </span>
            <span className="vmn-home-composer-count">
              {composer.workCount} {t("works")}
            </span>
          </AppLink>
        ))}
      </div>
    </section>
  );
}

function HowItWorks({ t }) {
  const steps = [
    { icon: "explore", title: t("findMusic", "Find music"), body: t("findMusicBody", "Search by title, composer, category or voice.") },
    { icon: "headphones", title: t("previewMusic", "Preview & choose"), body: t("previewMusicBody", "Listen to a short preview before you decide.") },
    { icon: "download", title: t("getMusic", "Get your score"), body: t("getMusicBody", "Download available scores and practice with the music.") },
  ];

  return (
    <section className="vmn-home-steps" aria-label={t("howItWorks", "How it works")}>
      <h2>{t("howItWorks", "How it works")}</h2>
      <div className="vmn-home-steps-grid">
        {steps.map((step, index) => {
          return (
            <article className="animate__animated animate__fadeInUp" key={step.title}>
              <span className="vmn-home-step-icon"><MaterialIcon name={step.icon} size={22} /></span>
              <strong>{index + 1}. {step.title}</strong>
              <p>{step.body}</p>
            </article>
          );
        })}
      </div>
    </section>
  );
}

function Statistics() {
  return (
    <section className="vmn-home-stats" aria-label="Statistics">
      {statistics.map((stat) => {
        return (
          <div className="vmn-home-stat animate__animated animate__fadeInUp" key={stat.label}>
            <MaterialIcon name={stat.icon} size={28} />
            <strong>{stat.value}</strong>
            <span>{stat.label}</span>
            {stat.detail && <small>{stat.detail}</small>}
          </div>
        );
      })}
    </section>
  );
}

function ContributorsMarquee({ t }) {
  return (
    <section className="vmn-contributors" aria-labelledby="vmn-contributors-title">
      <div className="vmn-contributors-heading">
        <div>
          <p className="vmn-home-section-kicker">{t("community", "Community")}</p>
          <h2 id="vmn-contributors-title">{t("contributorsTitle", "People behind the music")}</h2>
          <p>{t("contributorsIntro", "Composers, uploaders and choir leaders sharing sacred music.")}</p>
        </div>
        <AppLink href="/composers" className="vmn-home-text-link">
          {t("viewAll")} <MaterialIcon name="arrow_forward" size={18} />
        </AppLink>
      </div>
      <div className="vmn-contributors-viewport">
        <div className="vmn-contributors-track">
          {[0, 1].map((copy) => (
            <ul className="vmn-contributors-group" key={copy} aria-hidden={copy === 1 ? "true" : undefined}>
              {contributors.map((person) => (
                <li className="animate__animated animate__fadeInUp" key={`${copy}-${person.id}`}>
                  <img src={getProfilePhoto(person.photo)} alt={copy === 0 ? person.name : ""} loading="lazy" onError={handleAvatarError} />
                  <span className="vmn-contributors-person">
                    <strong>{person.name}</strong>
                    <small>{person.role}</small>
                  </span>
                </li>
              ))}
            </ul>
          ))}
        </div>
      </div>
    </section>
  );
}

export default function HomePage({ loading = false }) {
  const { t } = useTranslation();
  const { runSearch } = useApp();
  const [search, setSearch] = useState("");
  const [activeCategory, setActiveCategory] = useState(ALL);
  const [activePreviewId, setActivePreviewId] = useState(null);

  const handlePreviewPlay = useCallback((songId) => setActivePreviewId(songId), []);

  return (
    <div className="vmn-home">
      <Hero t={t} />

      <section className="vmn-home-search" aria-label={t("search")}>
        <div className="vmn-home-search-heading">
          <h2>{t("searchTitle", "Search the catalogue")}</h2>
          <p>{t("searchIntro", "Find the right piece for your choir in seconds.")}</p>
        </div>
        <SearchBar
          search={search}
          setSearch={setSearch}
          t={t}
          onSearch={runSearch}
        />
      </section>

      <RecentPublishingTicker t={t} />
      <NextSunday t={t} />

      <section className="vmn-home-section" id="categories">
        <div className="vmn-home-section-heading">
          <div>
            <p className="vmn-home-section-kicker">{t("explore")}</p>
            <h2>{t("browseCategory")}</h2>
          </div>
        </div>
        <CategoryFilter t={t} activeCategory={activeCategory} onChange={setActiveCategory} />
      </section>

      <FeaturedMusic
        t={t}
        loading={loading}
        activeCategory={activeCategory}
        onClearFilter={() => setActiveCategory(ALL)}
        activePreviewId={activePreviewId}
        onPreviewPlay={handlePreviewPlay}
      />

      <ComposerSpotlight t={t} />
      <HowItWorks t={t} />
      <Statistics />
      <ContributorsMarquee t={t} />
    </div>
  );
}
