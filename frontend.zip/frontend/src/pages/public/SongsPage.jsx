import { useEffect, useMemo, useRef, useState } from "react";
import { useNavigate, useSearch } from "@tanstack/react-router";

import AppLink from "../../components/common/AppLink.jsx";
import MaterialIcon from "../../components/common/MaterialIcon.jsx";
import MusicCard from "../../components/common/MusicCard.jsx";
import { songs } from "../../data/music.js";
import { useTranslation } from "../../i18n/useTranslation.js";
import { songMatchesQuery } from "../../services/catalogSearch.js";
import { getPreviewUrl } from "../../services/previewUrl.js";
import { libraryService } from "../../services/library.js";
import "./SongsPage.css";

function useFavorite(songId, t) {
  const [isFavorite, setIsFavorite] = useState(() => libraryService.isFavorite(songId));

  useEffect(() => libraryService.subscribe(() => {
    setIsFavorite(libraryService.isFavorite(songId));
  }), [songId]);

  function toggleFavorite() {
    libraryService.toggleFavorite(songId);
    setIsFavorite(libraryService.isFavorite(songId));
  }

  return {
    isFavorite,
    toggleFavorite,
    label: isFavorite
      ? `${t("remove", "Remove")} ${t("myFavorites", "favorites")}`
      : `${t("save", "Save")}`,
  };
}

function SongListRow({ song, position, t, categoryNames, onPreviewPlay, activePreviewId }) {
  const previewUrl = getPreviewUrl(song);
  const audioRef = useRef(null);
  const [audioError, setAudioError] = useState(false);
  const favorite = useFavorite(song.id, t);
  const playing = activePreviewId === song.id;
  const detailHref = song.slug
    ? `/song/${song.slug}`
    : `/search?q=${encodeURIComponent(song.title)}`;

  useEffect(() => {
    if (activePreviewId !== null && activePreviewId !== song.id) audioRef.current?.pause();
  }, [activePreviewId, song.id]);

  async function togglePreview() {
    const audio = audioRef.current;
    if (!audio || !previewUrl) return;
    if (playing) {
      audio.pause();
      onPreviewPlay(null);
      return;
    }
    onPreviewPlay(song.id);
    try {
      audio.currentTime = 0;
      await audio.play();
    } catch {
      setAudioError(true);
      onPreviewPlay(null);
    }
  }

  return (
    <article className={`vmn-song-row animate__animated animate__fadeInUp ${playing ? "is-playing" : ""}`}>
      <span className="vmn-song-row-index">{String(position).padStart(2, "0")}</span>

      <button
        type="button"
        className="vmn-song-row-play"
        onClick={togglePreview}
        disabled={!previewUrl || audioError}
        aria-label={playing ? `${t("pause", "Pause")} ${song.title}` : `${t("play", "Play")} ${song.title}`}
        title={!previewUrl ? t("noPreview", "Preview unavailable") : playing ? t("pause", "Pause") : t("play", "Play")}
      >
        <MaterialIcon name={playing ? "pause" : "play_arrow"} size={19} />
      </button>
      {previewUrl && (
        <audio
          ref={audioRef}
          src={previewUrl}
          preload="none"
          onEnded={() => onPreviewPlay(null)}
          onError={() => setAudioError(true)}
        />
      )}

      <div className="vmn-song-row-main">
        <AppLink href={detailHref} className="vmn-song-row-title">{song.title}</AppLink>
        <span>{song.composer}</span>
      </div>

      <span className="vmn-song-row-category">{categoryNames?.[song.category] || song.category}</span>
      <span className="vmn-song-row-voices">{song.voices}</span>

      <span className="vmn-song-row-rating" title={`${song.rating} / 5`}>
        <MaterialIcon name="star" size={16} />
        {song.rating} <small>({song.reviews})</small>
      </span>

      <div className="vmn-song-row-actions">
        <button
          type="button"
          className={`vmn-song-row-action ${favorite.isFavorite ? "is-active" : ""}`}
          onClick={favorite.toggleFavorite}
          aria-pressed={favorite.isFavorite}
          aria-label={`${favorite.label} ${song.title}`}
          title={favorite.label}
        >
          <MaterialIcon name={favorite.isFavorite ? "favorite" : "favorite_border"} size={18} />
        </button>
        {song.download_url && (
          <button
            type="button"
            className="vmn-song-row-action"
            onClick={() => window.open(song.download_url, "_blank", "noopener,noreferrer")}
            aria-label={`${t("download", "Download")} ${song.title}`}
            title={t("download", "Download")}
          >
            <MaterialIcon name="download" size={18} />
          </button>
        )}
        <AppLink
          href={detailHref}
          className="vmn-song-row-action"
          aria-label={`${t("view", "View")} ${song.title}`}
          title={t("view", "View")}
        >
          <MaterialIcon name="arrow_forward" size={18} />
        </AppLink>
      </div>
    </article>
  );
}

export default function SongsPage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const searchParams = useSearch({ from: "/songs" });
  const {
    q = "",
    category = "all",
    composer = "all",
    voice = "all",
    sort = "title",
  } = searchParams;
  const [view, setView] = useState("grid");
  const [activePreviewId, setActivePreviewId] = useState(null);

  const categories = useMemo(() => [...new Set(songs.map((song) => song.category))].sort(), []);
  const composers = useMemo(() => [...new Set(songs.map((song) => song.composer))].sort(), []);
  const voices = useMemo(() => [...new Set(songs.map((song) => song.voices).filter(Boolean))].sort(), []);

  const filteredSongs = useMemo(() => {
    const results = songs.filter((song) =>
      songMatchesQuery(song, q)
      && (category === "all" || song.category === category)
      && (composer === "all" || song.composer === composer)
      && (voice === "all" || song.voices === voice)
    );

    return [...results].sort((left, right) => (
      sort === "composer"
        ? left.composer.localeCompare(right.composer) || left.title.localeCompare(right.title)
        : left.title.localeCompare(right.title)
    ));
  }, [category, composer, q, sort, voice]);

  const groupedSongs = useMemo(() => filteredSongs.reduce((groups, song) => {
    (groups[song.category] ||= []).push(song);
    return groups;
  }, {}), [filteredSongs]);

  const hasQuery = Boolean(q.trim());

  function navigateWithSearch(patch) {
    const next = { ...searchParams, ...patch };
    const search = {};

    if (String(next.q ?? "").trim()) search.q = next.q;
    if (next.category && next.category !== "all") search.category = next.category;
    if (next.composer && next.composer !== "all") search.composer = next.composer;
    if (next.voice && next.voice !== "all") search.voice = next.voice;
    if (next.sort === "composer") search.sort = "composer";

    navigate({ to: "/songs", search, replace: true });
    setActivePreviewId(null);
  }

  function updateQuery(value) {
    navigateWithSearch({ q: value });
  }

  function updateFilter(key, value) {
    navigateWithSearch({ [key]: value });
  }

  function resetFilters() {
    navigate({ to: "/songs", search: {}, replace: true });
    setActivePreviewId(null);
  }

  const categoryNames = t("category");
  const activeFilterChips = [
    hasQuery && { key: "q", label: `${t("search", "Search")}: ${q}`, onRemove: () => updateQuery("") },
    category !== "all" && { key: "category", label: categoryNames?.[category] || category, onRemove: () => updateFilter("category", "all") },
    composer !== "all" && { key: "composer", label: composer, onRemove: () => updateFilter("composer", "all") },
    voice !== "all" && { key: "voice", label: voice, onRemove: () => updateFilter("voice", "all") },
    sort === "composer" && { key: "sort", label: `${t("sortBy", "Sort by")}: ${t("composer", "Composer")}`, onRemove: () => updateFilter("sort", "title") },
  ].filter(Boolean);

  return (
    <div className="vmn-songs-page">
      <section className="vmn-songs-hero">
        <div className="vmn-songs-hero-inner">
          <div className="vmn-songs-hero-copy">
            <h1>{t("allSongs", "All Songs")}</h1>
            <p className="vmn-songs-hero-intro">
              {t("songsPageIntro", "Browse the collection or search by title, composer, category, or voice.")}
            </p>
          </div>

          <div className="vmn-songs-hero-search-wrap">
            <form className="vmn-songs-search" role="search" onSubmit={(event) => event.preventDefault()}>
              <MaterialIcon name="search" size={24} aria-hidden="true" />
              <input
                type="search"
                value={q}
                onChange={(event) => updateQuery(event.target.value)}
                placeholder={t("songsSearchPlaceholder", "Search songs or composers")}
                aria-label={t("search", "Search")}
              />
              {q && (
                <button type="button" onClick={() => updateQuery("")} aria-label={t("clearSearch", "Clear search")}>
                  <MaterialIcon name="close" size={20} />
                </button>
              )}
            </form>

            {q && (
              <p className="vmn-songs-search-count" aria-live="polite">
                {filteredSongs.length} {t(filteredSongs.length === 1 ? "song" : "songs")}
              </p>
            )}
          </div>

          <div className="vmn-songs-filterbar">
            <span className="vmn-songs-filterbar-label">
              <MaterialIcon name="tune" size={18} />
              {t("filters", "Filters")}
              {activeFilterChips.length > 0 && <span className="vmn-songs-filter-count">{activeFilterChips.length}</span>}
            </span>
            <label>
              <span>{t("categoryFilter", "Category")}</span>
              <select value={category} onChange={(event) => updateFilter("category", event.target.value)}>
                <option value="all">{t("allCategories", "All categories")}</option>
                {categories.map((item) => <option key={item} value={item}>{categoryNames?.[item] || item}</option>)}
              </select>
            </label>
            <label>
              <span>{t("composer", "Composer")}</span>
              <select value={composer} onChange={(event) => updateFilter("composer", event.target.value)}>
                <option value="all">{t("allComposers", "All composers")}</option>
                {composers.map((item) => <option key={item} value={item}>{item}</option>)}
              </select>
            </label>
            <label>
              <span>{t("voices", "Voices")}</span>
              <select value={voice} onChange={(event) => updateFilter("voice", event.target.value)}>
                <option value="all">{t("allVoices", "All voices")}</option>
                {voices.map((item) => <option key={item} value={item}>{item}</option>)}
              </select>
            </label>
            <label>
              <span>{t("sortBy", "Sort by")}</span>
              <select value={sort} onChange={(event) => updateFilter("sort", event.target.value)}>
                <option value="title">{t("songTitle", "Title")}</option>
                <option value="composer">{t("composer", "Composer")}</option>
              </select>
            </label>
          </div>

          {activeFilterChips.length > 0 && (
            <div className="vmn-songs-active-filters" aria-label={t("activeFilters", "Active filters")}>
              {activeFilterChips.map((chip) => (
                <button key={chip.key} type="button" onClick={chip.onRemove} title={t("removeFilter", "Remove filter")} className="animate__animated animate__fadeInUp">
                  <span>{chip.label}</span>
                  <MaterialIcon name="close" size={14} />
                </button>
              ))}
              <button type="button" className="vmn-songs-clear-all animate__animated animate__fadeInUp" onClick={resetFilters}>
                {t("clearAll", "Clear all")}
              </button>
            </div>
          )}
        </div>
      </section>

      <section className="vmn-songs-catalog" aria-label={t("allSongs", "All Songs")}>
        <div className="vmn-songs-results-heading">
          <div>
            <h2>{t("songs", "Songs")}</h2>
            <span aria-live="polite">
              {filteredSongs.length} {t(filteredSongs.length === 1 ? "song" : "songs")}
            </span>
          </div>
          <div className="vmn-songs-view-switch" role="group" aria-label={t("viewMode", "View mode")}>
            <button
              type="button"
              className={view === "list" ? "is-active" : ""}
              onClick={() => setView("list")}
              aria-pressed={view === "list"}
              title={t("listView", "List view")}
            >
              <MaterialIcon name="list" size={19} />
              <span>{t("listView", "List")}</span>
            </button>
            <button
              type="button"
              className={view === "grid" ? "is-active" : ""}
              onClick={() => setView("grid")}
              aria-pressed={view === "grid"}
              title={t("gridView", "Grid view")}
            >
              <MaterialIcon name="grid_view" size={19} />
              <span>{t("gridView", "Grid")}</span>
            </button>
          </div>
        </div>

        {filteredSongs.length === 0 ? (
          <div className="vmn-songs-empty">
            <MaterialIcon name="music_off" size={34} />
            <p>{t("noSongsFound", "No songs found.")}</p>
            <button type="button" onClick={resetFilters}>{t("clearFilters", "Clear filters")}</button>
          </div>
        ) : (
          <div className="vmn-songs-groups">
            {Object.entries(groupedSongs).map(([groupName, groupSongs]) => (
              <section className="vmn-songs-group animate__animated animate__fadeInUp" key={groupName} aria-label={categoryNames?.[groupName] || groupName}>
                <header>
                  <div>
                    <MaterialIcon name="music_note" size={21} />
                    <h3>{categoryNames?.[groupName] || groupName}</h3>
                  </div>
                  <span>{groupSongs.length}</span>
                </header>

                {view === "grid" ? (
                  <div className="featured-grid vmn-songs-grid">
                    {groupSongs.map((song) => (
                      <MusicCard
                        key={song.id}
                        song={song}
                        t={t}
                        onPreviewPlay={setActivePreviewId}
                        activePreviewId={activePreviewId}
                      />
                    ))}
                  </div>
                ) : (
                  <div className="vmn-songs-list">
                    <div className="vmn-song-row vmn-song-row-head" aria-hidden="true">
                      <span />
                      <span />
                      <span>{t("songTitle", "Title")}</span>
                      <span>{t("categoryFilter", "Category")}</span>
                      <span>{t("voices", "Voices")}</span>
                      <span>{t("rating", "Rating")}</span>
                      <span />
                    </div>
                    {groupSongs.map((song, index) => (
                      <SongListRow
                        key={song.id}
                        song={song}
                        position={index + 1}
                        t={t}
                        categoryNames={categoryNames}
                        onPreviewPlay={setActivePreviewId}
                        activePreviewId={activePreviewId}
                      />
                    ))}
                  </div>
                )}
              </section>
            ))}
          </div>
        )}
      </section>
    </div>
  );
}
