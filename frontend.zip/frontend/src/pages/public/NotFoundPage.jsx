import AppLink from '../../components/common/AppLink.jsx';
import MaterialIcon from '../../components/common/MaterialIcon.jsx';
import { useTranslation } from '../../i18n/useTranslation.js';
import './NotFoundPage.css';

export default function NotFoundPage() {
  const { t } = useTranslation();

  return (
    <section className="not-found-page" aria-labelledby="not-found-title">
      <div className="not-found-card">
        <span className="not-found-code" aria-hidden="true">404</span>
        <span className="not-found-icon"><MaterialIcon name="music_off" size={28} /></span>
        <span className="not-found-eyebrow">{t('notFoundEyebrow', 'Page not found')}</span>
        <h1 id="not-found-title">{t('notFoundTitle', 'This page is off the score')}</h1>
        <p>{t('notFoundDesc', "We couldn't find the page you were looking for. It may have moved or the link may be out of date.")}</p>
        <div className="not-found-actions">
          <AppLink href="/" className="not-found-primary"><MaterialIcon name="home" size={18} />{t('home', 'Home')}</AppLink>
          <AppLink href="/search" className="not-found-secondary"><MaterialIcon name="search" size={18} />{t('search', 'Search')}</AppLink>
        </div>
        <div className="not-found-links">
          <span>{t('quickLinks', 'Quick links')}</span>
          <AppLink href="/songs">{t('songs', 'Songs')}</AppLink>
          <AppLink href="/composers">{t('composers', 'Composers')}</AppLink>
          <AppLink href="/about">{t('about', 'About')}</AppLink>
        </div>
      </div>
    </section>
  );
}
