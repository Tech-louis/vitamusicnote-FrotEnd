import { useMemo, useState } from "react";
import MusicCard from "../../components/common/MusicCard.jsx";
import MaterialIcon from "../../components/common/MaterialIcon.jsx";
import { composers } from "../../data/composers.js";
import { getProfilePhoto, handleAvatarError } from "../../data/profile.js";
import { composerMatchesQuery, normalizeQuery } from "../../services/catalogSearch.js";
import { useTranslation } from "../../i18n/useTranslation.js";
import "./PageHero.css";
import "./ComposersPage.css";

export default function ComposersPage() {
  const { t } = useTranslation();
  const [query, setQuery] = useState("");
  const [location, setLocation] = useState("all");
  const [sortBy, setSortBy] = useState("name");
  const [selectedId, setSelectedId] = useState(null);
  const [activePreviewId, setActivePreviewId] = useState(null);

  const locations = useMemo(
    () => [...new Set(composers.map((composer) => composer.location))].sort(),
    []
  );

  const filtered = useMemo(() => {
    const results = composers.filter((composer) =>
      (location === "all" || composer.location === location) &&
      composerMatchesQuery(composer, query)
    );

    return results.sort((left, right) => {
      if (sortBy === "works") return right.workCount - left.workCount;
      if (sortBy === "rating") return (Number(right.rating) || 0) - (Number(left.rating) || 0);
      return left.name.localeCompare(right.name);
    });
  }, [location, query, sortBy]);

  const hasSearchControls = Boolean(normalizeQuery(query)) || location !== "all" || sortBy !== "name";

  function clearSearch() {
    setQuery("");
    setLocation("all");
    setSortBy("name");
  }

  const selected = composers.find((composer) => composer.id === selectedId);

  function showWorks(composerId) {
    setSelectedId(composerId);
    setActivePreviewId(null);
    requestAnimationFrame(() => {
      document.getElementById("composer-works")?.scrollIntoView({ behavior: "smooth", block: "start" });
    });
  }

  return (
    <div className="composers-page" id="composers">
      <header className="vmn-page-hero">
        <p className="eyebrow">{t("composersEyebrow")}</p>
        <h1>{t("composersTitle")}</h1>
        <p>{t("composersIntro")}</p>
      </header>

      <section className="composer-directory" aria-label={t("composers")}>
        <div className="composer-directory-heading">
          <div>
            <h2>{t("composers")}</h2>
            <span className="composer-count">{filtered.length}</span>
          </div>

          <label className="composer-search">
            <MaterialIcon name="search" size={19} />
            <span className="sr-only">{t("composerSearch")}</span>
            <input
              type="search"
              value={query}
              onChange={(event) => setQuery(event.target.value)}
              placeholder={t("composerSearch")}
              aria-label={t("composerSearch")}
            />
            {query && (
              <button
                type="button"
                className="composer-search-clear"
                onClick={() => setQuery("")}
                aria-label={t("clearSearch", "Clear search")}
              >
                <MaterialIcon name="close" size={17} />
              </button>
            )}
          </label>
        </div>

        <div className="composer-search-controls" aria-label="Composer search controls">
          <label>
            <span>{t("location", "Location")}</span>
            <select value={location} onChange={(event) => setLocation(event.target.value)}>
              <option value="all">{t("allLocations", "All locations")}</option>
              {locations.map((item) => (
                <option key={item} value={item}>{item}</option>
              ))}
            </select>
          </label>
          <label>
            <span>{t("sortBy", "Sort by")}</span>
            <select value={sortBy} onChange={(event) => setSortBy(event.target.value)}>
              <option value="name">{t("name", "Name")}</option>
              <option value="works">{t("mostWorks", "Most works")}</option>
              <option value="rating">{t("highestRated", "Highest rated")}</option>
            </select>
          </label>
          {hasSearchControls && (
            <button type="button" className="composer-search-reset" onClick={clearSearch}>
              {t("reset")}
            </button>
          )}
        </div>

        {filtered.length === 0 ? (
          <div className="composer-no-results">
            <MaterialIcon name="search_off" size={28} />
            <p>{t("noComposers")}</p>
            <button type="button" onClick={clearSearch}>{t("clearSearch", "Clear search")}</button>
          </div>
        ) : (
          <div className="composer-grid">
            {filtered.map((composer) => {
              const isSelected = selectedId === composer.id;

              return (
                <article
                  className={`composer-card animate__animated animate__fadeInUp ${isSelected ? "is-selected" : ""}`}
                  key={composer.id}
                >
                  <div className="composer-card-top">
                    <img className="composer-avatar" src={getProfilePhoto(composer.photo)} alt="" onError={handleAvatarError} />
                    <div className="composer-identity">
                      <h3>{composer.name}</h3>
                      <span className="composer-focus">{composer.focus}</span>
                    </div>
                  </div>

                  <p className="composer-bio">{composer.bio}</p>

                  <div className="composer-meta">
                    <span><MaterialIcon name="location_on" size={17} /> {composer.location}</span>
                    <span><MaterialIcon name="music_note" size={17} /> {composer.workCount} {t("works")}</span>
                    {composer.rating && (
                      <span><MaterialIcon name="star" size={17} style={{ color: "#F5B400" }} /> {composer.rating}</span>
                    )}
                  </div>

                  <button
                    type="button"
                    className="composer-works-button"
                    onClick={() => showWorks(composer.id)}
                    aria-expanded={isSelected}
                  >
                    {t("viewWorks")} <MaterialIcon name="arrow_forward" size={18} />
                  </button>
                </article>
              );
            })}
          </div>
        )}
      </section>

      <section className="composer-works-section" id="composer-works">
        <div className="section-heading">
          <h2>{selected ? selected.name : t("composerWorks")}</h2>
        </div>

        {!selected ? (
          <p className="composer-empty-hint">{t("selectComposer")}</p>
        ) : selected.works.length === 0 ? (
          <p className="no-results">{t("composerNoWorks")}</p>
        ) : (
          <div className="featured-grid">
            {selected.works.map((song) => (
              <MusicCard
                key={song.id}
                song={song}
                t={t}
                onPreviewPlay={setActivePreviewId}
                activePreviewId={activePreviewId}
              />
            ))}
          </div>
        )}
      </section>

    </div>
  );
}
