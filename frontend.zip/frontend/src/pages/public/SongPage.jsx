import AppLink from "../../components/common/AppLink.jsx";
import MaterialIcon from "../../components/common/MaterialIcon.jsx";
import { useTranslation } from "../../i18n/useTranslation.js";
import "./SongPage.css";

const songsBySlug = {
  "ee-bwana-ikupendeze": {
    title: "Ee Bwana Ikupendeze",
    composer: "Mwl. Joseph David Mkomagu (1951 − 2013)",
    composedOn: "08 November 1991",
    place: "Morogoro Diocese, Tanzania",
    publishedOn: "19 February 2025, 10:06 AM",
    category: "Offertory",
    theme: "Humility before God",
    paragraphs: [
      "“Ee Bwana Ikupendeze” was the first official publication on VitaMusicNote. It was composed on 08 November 1991 in Morogoro Diocese, Tanzania, by the late Mwl. Joseph David Mkomagu and published on VitaMusicNote on 19 February 2025 at 10:06 AM.",
      "It is an Offertory song emphasizing humility before God, reminding believers that everything belongs to Him. Interestingly, this was not originally planned to become the first published song. Instead, it became a symbolic prayer asking God to accept and bless this mission.",
      "Originally, another song titled “Hiki ni Chakula” by the late Charles C. Saasita had been prepared as the first publication. Technical challenges temporarily removed all website content, and during restoration “Ee Bwana Ikupendeze” unintentionally became the first song uploaded again. From that moment onward, the journey never stopped.",
    ],
  },
};

export default function SongPage({ slug }) {
  const { t } = useTranslation();
  const song = songsBySlug[slug];

  if (!song) {
    return (
      <div className="song-page">
        <AppLink href="/songs" className="song-back">
          <MaterialIcon name="arrow_back" size={18} /> {t("allSongs", "All Songs")}
        </AppLink>
        <div className="song-body">
          <h2>Song not found</h2>
          <p>We could not find this song in the VitaMusicNote library.</p>
        </div>
      </div>
    );
  }

  return (
    <div className="song-page">
      <AppLink href="/songs" className="song-back">
        <MaterialIcon name="arrow_back" size={18} /> {t("allSongs", "All Songs")}
      </AppLink>

      <header className="song-hero">
        <span className="song-eyebrow"><MaterialIcon name="music_note" size={16} /> First published song</span>
        <h1>{song.title}</h1>
        <p>{song.composer}</p>
      </header>

      <div className="song-meta">
        <div className="song-meta-item animate__animated animate__fadeInUp">
          <span><MaterialIcon name="event" size={16} /> Composed</span>
          <strong>{song.composedOn}</strong>
        </div>
        <div className="song-meta-item animate__animated animate__fadeInUp">
          <span><MaterialIcon name="location_on" size={16} /> Place</span>
          <strong>{song.place}</strong>
        </div>
        <div className="song-meta-item animate__animated animate__fadeInUp">
          <span><MaterialIcon name="menu_book" size={16} /> Liturgical use</span>
          <strong>{song.category} · {song.theme}</strong>
        </div>
        <div className="song-meta-item animate__animated animate__fadeInUp">
          <span><MaterialIcon name="event" size={16} /> Published</span>
          <strong>{song.publishedOn}</strong>
        </div>
      </div>

      <article className="song-body">
        <h2>About this song</h2>
        {song.paragraphs.map((paragraph) => <p key={paragraph}>{paragraph}</p>)}
        <div className="song-notice">
          <MaterialIcon name="music_note" size={20} />
          <span>Printed notation and MIDI practice files for this work will appear here when the music library is connected.</span>
        </div>
      </article>
    </div>
  );
}
