import { useCallback, useMemo, useState } from "react";
import { useNavigate, useSearch } from "@tanstack/react-router";

import AppLink from "../../components/common/AppLink.jsx";
import MusicCard from "../../components/common/MusicCard.jsx";
import MaterialIcon from "../../components/common/MaterialIcon.jsx";
import { normalizeQuery, searchCatalog } from "../../services/catalogSearch.js";
import { useTranslation } from "../../i18n/useTranslation.js";
import "./SearchPage.css";

export default function SearchPage() {
  const { t } = useTranslation();
  const navigate = useNavigate();
  const { q = "" } = useSearch({ from: "/search" });
  const [activePreviewId, setActivePreviewId] = useState(null);

  const handlePreviewPlay = useCallback((songId) => setActivePreviewId(songId), []);

  // The URL is the single source of truth, so the page is always shareable
  // and back/forward navigation restores the exact query.
  const input = q;
  const results = useMemo(() => searchCatalog(input), [input]);
  const hasQuery = Boolean(normalizeQuery(input));

  function updateQuery(value) {
    // Keep the raw value in the URL so multi-word queries can be typed with
    // spaces; searchCatalog normalizes it for matching.
    navigate({ to: "/search", search: value ? { q: value } : {}, replace: true });
  }

  function submit(event) {
    event.preventDefault();
    updateQuery(input);
  }

  return (
    <div className="vmn-search-page">
      <header className="vmn-page-hero">
        <p className="eyebrow">{t("search")}</p>
        <h1>{t("searchTitle")}</h1>
        <p>{t("searchIntro")}</p>
      </header>

      <form className="vmn-search-page-field" role="search" onSubmit={submit}>
        <MaterialIcon name="search" size={22} />
        <span className="sr-only">{t("search")}</span>
        <input
          type="search"
          value={input}
          onChange={(event) => {
            updateQuery(event.target.value);
            setActivePreviewId(null);
          }}
          placeholder={t("searchSongsComposers")}
          aria-label={t("search")}
        />
        {input && (
          <button
            type="button"
            onClick={() => {
              updateQuery("");
              setActivePreviewId(null);
            }}
            aria-label={t("clearSearch", "Clear search")}
            className="grid h-8 w-8 shrink-0 place-items-center rounded-full text-[#8b968e] hover:bg-[#f1f6f2] dark:hover:bg-[#1d3326]"
          >
            <MaterialIcon name="close" size={18} />
          </button>
        )}
        <button
          type="submit"
          className="inline-flex h-9 shrink-0 items-center gap-1.5 rounded-full bg-brand px-4 text-xs font-bold text-white transition-colors hover:bg-brand-dark disabled:opacity-50"
          disabled={!hasQuery}
        >
          {t("search")} <MaterialIcon name="arrow_forward" size={18} />
        </button>
      </form>

      {!hasQuery ? (
        <p className="vmn-search-hint">{t("searchNoQuery")}</p>
      ) : results.songs.length + results.composers.length === 0 ? (
        <p className="no-results">{t("searchNoResults")}</p>
      ) : (
        <>
          <p className="vmn-search-result-count">
            {results.songs.length + results.composers.length} {t("searchResultsCount")}
          </p>

          {results.songs.length > 0 && (
            <div className="featured-grid">
              {results.songs.map((song) => (
                <MusicCard
                  key={song.id}
                  song={song}
                  t={t}
                  onPreviewPlay={handlePreviewPlay}
                  activePreviewId={activePreviewId}
                />
              ))}
            </div>
          )}

          {results.composers.length > 0 && (
            <section className="vmn-search-composers" aria-label={t("composers")}>
              <h2>{t("composers")}</h2>
              <div className="vmn-search-composer-grid">
                {results.composers.map((composer) => (
                  <AppLink
                    key={composer.id}
                    href="/composers"
                    className="vmn-search-composer-card animate__animated animate__fadeInUp"
                  >
                    <span className="vmn-search-composer-icon"><MaterialIcon name="person" size={20} /></span>
                    <span className="min-w-0">
                      <strong>{composer.name}</strong>
                      <small>{composer.workCount} {t("works")} · {composer.location}</small>
                    </span>
                    <MaterialIcon name="arrow_forward" size={18} />
                  </AppLink>
                ))}
              </div>
            </section>
          )}
        </>
      )}
    </div>
  );
}
