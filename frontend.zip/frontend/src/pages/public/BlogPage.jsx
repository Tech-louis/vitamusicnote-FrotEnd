import MaterialIcon from "../../components/common/MaterialIcon.jsx";
import { useTranslation } from "../../i18n/useTranslation.js";
import "./PageHero.css";
import "./BlogPage.css";

export default function BlogPage() {
  const { t } = useTranslation();
  return (
    <div className="vmn-blog-page">
      <header className="vmn-page-hero">
        <p className="eyebrow">VITAMUSICNOTE</p>
        <h1>{t("blogTitle")}</h1>
        <p>{t("blogIntro")}</p>
      </header>
      <div className="vmn-blog-empty">
        <MaterialIcon name="article" size={30} />
        <p>{t("blogIntro")}</p>
      </div>
    </div>
  );
}
