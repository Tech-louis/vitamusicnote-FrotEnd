import { useCallback, useEffect, useMemo, useState } from "react";
import { translations } from "./translations.js";
import { languages } from "../data/languages.js";
import { LanguageContext } from "./languageContext.js";

const STORAGE_KEY = "vitamusicnote-language";
const DEFAULT_LANGUAGE = "SW";
const SUPPORTED_LANGUAGES = languages.map((item) => item.code);

function readInitialLanguage() {
  try {
    const saved = localStorage.getItem(STORAGE_KEY);
    return SUPPORTED_LANGUAGES.includes(saved) ? saved : DEFAULT_LANGUAGE;
  } catch {
    return DEFAULT_LANGUAGE;
  }
}

function resolveKey(dictionary, key) {
  return String(key).split(".").reduce((value, part) => (
    value && typeof value === "object" ? value[part] : undefined
  ), dictionary);
}

export function LanguageProvider({ children, initialLanguage }) {
  const [language, setLanguageState] = useState(initialLanguage || DEFAULT_LANGUAGE);
  const [languageReady, setLanguageReady] = useState(Boolean(initialLanguage));

  const setLanguage = useCallback((nextLanguage) => {
    if (SUPPORTED_LANGUAGES.includes(nextLanguage)) setLanguageState(nextLanguage);
  }, []);

  const t = useCallback((key, fallback) => {
    const current = resolveKey(translations[language], key);
    if (current !== undefined && current !== null) return current;
    const english = resolveKey(translations.EN, key);
    if (english !== undefined && english !== null) return english;
    return fallback ?? key;
  }, [language]);

  useEffect(() => {
    const frame = window.requestAnimationFrame(() => {
      if (!initialLanguage) setLanguageState(readInitialLanguage());
      setLanguageReady(true);
    });
    return () => window.cancelAnimationFrame(frame);
  }, [initialLanguage]);

  useEffect(() => {
    if (!languageReady) return;
    try { localStorage.setItem(STORAGE_KEY, language); } catch { /* storage may be unavailable */ }
    const languageTag = ({ SW: "sw", EN: "en", FR: "fr", RN: "rn", LN: "ln", RW: "rw" })[language] || "en";
    document.documentElement.lang = languageTag;
  }, [language, languageReady]);

  const value = useMemo(() => ({
    language, setLanguage, changeLanguage: setLanguage, t,
    supportedLanguages: languages,
  }), [language, setLanguage, t]);

  return <LanguageContext.Provider value={value}>{children}</LanguageContext.Provider>;
}

