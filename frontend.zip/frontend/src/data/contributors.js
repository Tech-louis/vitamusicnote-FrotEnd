/* People featured in the home page contributors marquee.
   Contributors without an uploaded photo automatically use the default profile picture. */
export const contributors = [
  { id: "linus-john", name: "Linus John", role: "Founder" },
  { id: "emmanuel-mhando", name: "Emmanuel Mhando", role: "Composer" },
  { id: "maria-mwesigawa", name: "Sr. Maria Mwesigawa", role: "Composer" },
  { id: "john-kamanzi", name: "John B. Kamanzi", role: "Composer" },
];
