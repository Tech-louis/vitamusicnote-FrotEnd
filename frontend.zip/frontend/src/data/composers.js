import { songs } from "./music.js";

/* Composer profiles are enriched from the catalogue so the public directory
   stays in sync when real API data replaces the demo song list. */
const profiles = {
  "Emmanuel Mhando": {
    location: "Dar es Salaam, Tanzania",
    focus: "Hymns & Choral Works",
    bio: "Composes accessible congregational hymns with rich four-part harmony for choir and assembly.",
  },
  "Sr. Maria Mwesigawa": {
    location: "Arusha, Tanzania",
    focus: "Mass Settings & Liturgical Music",
    bio: "Writes prayerful Mass settings that follow the liturgical calendar and support congregational singing.",
  },
  "John B. Kamanzi": {
    location: "Kigali, Rwanda",
    focus: "Psalms & Spiritual Songs",
    bio: "Blends African rhythmic patterns with classical choral writing for contemporary worship communities.",
  },
};

function initialsFor(name) {
  return name
    .replace(/^(Sr\.|Fr\.|Dr\.)\s+/i, "")
    .split(/\s+/)
    .filter(Boolean)
    .slice(0, 2)
    .map((part) => part[0].toUpperCase())
    .join("");
}

export const composers = [...new Set(songs.map((song) => song.composer))]
  .filter(Boolean)
  .map((name) => {
    const works = songs.filter((song) => song.composer === name);
    const ratings = works
      .map((song) => Number(song.rating))
      .filter((value) => Number.isFinite(value));

    return {
      id: name.toLowerCase().replace(/[^a-z0-9]+/g, "-").replace(/^-|-$/g, ""),
      name,
      works,
      workCount: works.length,
      rating: ratings.length
        ? (ratings.reduce((sum, value) => sum + value, 0) / ratings.length).toFixed(1)
        : null,
      initials: initialsFor(name),
      ...(profiles[name] || {
        location: "Tanzania",
        focus: "Sacred & Choral Music",
        bio: "Contributor to the VitaMusicNote sacred music library.",
      }),
    };
  });
