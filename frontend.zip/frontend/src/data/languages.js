export const languages = [
  { code: "SW", name: "Kiswahili", flag: "https://flagcdn.com/w40/tz.png" },
  { code: "EN", name: "English", flag: "https://flagcdn.com/w40/gb.png" },
  { code: "FR", name: "Français", flag: "https://flagcdn.com/w40/fr.png" },
  { code: "RN", name: "Kirundi", flag: "https://flagcdn.com/w40/bi.png" },
  { code: "LN", name: "Lingala", flag: "https://flagcdn.com/w40/cd.png" },
  { code: "RW", name: "Kinyarwanda", flag: "https://flagcdn.com/w40/rw.png" },
];
