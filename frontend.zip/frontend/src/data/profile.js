/* Fallback profile picture used for members and contributors without an uploaded photo. */
export const DEFAULT_AVATAR = "/images/brand/default.png";

export function getProfilePhoto(photo) {
  return photo || DEFAULT_AVATAR;
}

/** Recover gracefully when a stored profile photo URL is missing or broken. */
export function handleAvatarError(event) {
  const image = event.currentTarget;
  if (!image.src.endsWith(DEFAULT_AVATAR)) image.src = DEFAULT_AVATAR;
}
