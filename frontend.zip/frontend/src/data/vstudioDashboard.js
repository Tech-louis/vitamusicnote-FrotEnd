export const dashboardProfile = {
  accountLabel: 'Your account',
  fallbackName: 'Louis Salvatory',
  title: 'Studio dashboard',
};

export const dashboardNav = [
  { label: 'Nyumbani', href: '/', icon: 'home' },
  { label: 'Dashibodi', href: '/vstudio', icon: 'space_dashboard' },
  { label: 'Wasifu', href: '/vstudio/profile', icon: 'person' },
  { label: 'Pakia', href: '#uploads', icon: 'upload' },
  { label: 'Maudhui', href: '#content', icon: 'library_music' },
  { label: 'Takwimu', href: '#stats', icon: 'monitoring' },
  { label: 'Mipangilio', href: '/vstudio/settings', icon: 'settings' },
  { label: 'Kagua', href: '#review', icon: 'rate_review' },
];

export const dashboardStats = [
  {
    id: 'songs',
    label: 'Songs (Published / Total)',
    value: '37 / 37',
    change: '▲+100%',
    note: '0 new this month',
    icon: 'library_music',
  },
  {
    id: 'views',
    label: 'Views (last 21d)',
    value: '374',
    change: '▲+60.52%',
    note: '',
    icon: 'visibility',
  },
  {
    id: 'downloads',
    label: 'Downloads (last 21d)',
    value: '21',
    change: '▲+90.91%',
    note: '',
    icon: 'download',
  },
  {
    id: 'engagement',
    label: 'Likes · Shares (last 21d)',
    value: '1 · 5',
    change: '▲+100%  ▲+400%',
    note: 'Engagement 7.22%',
    icon: 'favorite',
  },
];

export const studioPulse = [
  { label: 'Followers', value: '0', note: '0 / 28d' },
  { label: 'Views (48h)', value: '73', note: '' },
  { label: 'Avg. view/day (21d)', value: '18', note: '' },
  { label: 'Completion %', value: '45%', note: '' },
];

export const topSongs = [
  { title: 'Njoo Kwetu Masiha', views: 14 },
  { title: 'Anakuja Masiya', views: 12 },
  { title: 'Uje Kwetu Masiha', views: 10 },
  { title: 'Tujongee Mezani kwa Bwana', views: 6 },
  { title: 'Kaa Nasi Bwana', views: 5 },
];

export const viewsEngagementLabels = Array.from({ length: 21 }, (_, index) => `D${index + 1}`)

export const viewsEngagementSeries = [
  {
    id: 'views',
    label: 'Views',
    color: '#08752d',
    values: [8, 12, 10, 15, 22, 18, 14, 20, 25, 17, 11, 9, 16, 21, 19, 24, 27, 23, 18, 16, 29],
  },
  {
    id: 'engagement',
    label: 'Engagement',
    color: '#f59e0b',
    values: [4.2, 5.1, 4.8, 6.3, 7.9, 6.8, 5.7, 7.2, 8.4, 6.6, 5.2, 4.9, 6.1, 7.5, 7, 8.1, 9.2, 8.6, 7.4, 6.9, 8.8],
  },
];

export const viewsDownloadsSeries = {
  labels: ['D1', 'D3', 'D5', 'D7', 'D9', 'D11', 'D13', 'D15', 'D17', 'D19', 'D21'],
  views: [30, 47, 42, 67, 86, 54, 42, 70, 84, 63, 92],
  downloads: [1, 2, 2, 4, 5, 2, 2, 4, 5, 3, 6],
};

export const uploadsByType = {
  months: ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'],
  series: [
    { id: 'pdf', label: 'PDF', color: '#08752d', values: [2, 1, 3, 2, 4, 3, 2, 5, 4, 3, 2, 1] },
    { id: 'mp3', label: 'MP3', color: '#2563eb', values: [3, 2, 4, 3, 5, 4, 3, 6, 5, 4, 3, 2] },
    { id: 'chord', label: 'Chord', color: '#f59e0b', values: [1, 1, 2, 1, 2, 2, 1, 3, 2, 2, 1, 1] },
    { id: 'score', label: 'Score', color: '#dc2626', values: [0, 1, 1, 2, 1, 2, 1, 2, 2, 1, 1, 0] },
  ],
};

export const actionsMix = [
  { label: 'Likes', value: 1, color: '#f59e0b' },
  { label: 'Shares', value: 5, color: '#2563eb' },
  { label: 'Downloads', value: 21, color: '#08752d' },
];

export const recentUploads = [
  { title: 'Njoo Kwetu Masiha', type: 'MP3', date: '2d ago', status: 'Published' },
  { title: 'Anakuja Masiya', type: 'PDF', date: '3d ago', status: 'Published' },
  { title: 'Uje Kwetu Masiha', type: 'Chord', date: '5d ago', status: 'Published' },
  { title: 'Tujongee Mezani kwa Bwana', type: 'MP3', date: '6d ago', status: 'Published' },
  { title: 'Kaa Nasi Bwana', type: 'Score', date: '8d ago', status: 'Published' },
];
