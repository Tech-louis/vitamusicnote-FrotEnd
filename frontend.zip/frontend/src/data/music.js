/**
 * Catalogue categories (cleaned source data).
 * Duplicate "Jumla" rows and the "Shukrani"/"Shukurani" spelling variant were merged.
 * primaryMetric and secondaryMetric are kept neutral until their labels are confirmed.
 */
export const categories = [
  { name: "Majilio", icon: "calendar_month", songCount: 108, primaryMetric: 55588, secondaryMetric: 1301 },
  { name: "Noeli", icon: "celebration", songCount: 137, primaryMetric: 73568, secondaryMetric: 3617 },
  { name: "Pasaka", icon: "celebration", songCount: 313, primaryMetric: 26754, secondaryMetric: 1015 },
  { name: "Pentekoste", icon: "auto_awesome", songCount: 31, primaryMetric: 12393, secondaryMetric: 244 },
  { name: "Kwaresima", icon: "self_improvement", songCount: 387, primaryMetric: 36841, secondaryMetric: 1366 },
  { name: "Aleluya", icon: "celebration", songCount: 51, primaryMetric: 7211, secondaryMetric: 377 },
  { name: "Alhamisi Kuu", icon: "groups", songCount: 26, primaryMetric: 3100, secondaryMetric: 60 },
  { name: "Anthem", icon: "library_music", songCount: 143, primaryMetric: 14886, secondaryMetric: 730 },
  { name: "Ekaristi/Komunyo", icon: "church", songCount: 165, primaryMetric: 18450, secondaryMetric: 762 },
  { name: "Injili", icon: "menu_book", songCount: 50, primaryMetric: 5695, secondaryMetric: 252 },
  { name: "Juma Kuu", icon: "church", songCount: 284, primaryMetric: 23058, secondaryMetric: 862 },
  { name: "Jumla", icon: "music_note", songCount: 942, primaryMetric: 94531, secondaryMetric: 4603 },
  { name: "Katikati", icon: "music_note", songCount: 203, primaryMetric: 41999, secondaryMetric: 1206 },
  { name: "Kiswahili", icon: "translate", songCount: 1068, primaryMetric: 173265, secondaryMetric: 6027 },
  { name: "Kupaa kwa Bwana", icon: "north_east", songCount: 26, primaryMetric: 3452, secondaryMetric: 100 },
  { name: "Mafundisho/Tafakari", icon: "menu_book", songCount: 450, primaryMetric: 80539, secondaryMetric: 3460 },
  { name: "Misa", icon: "church", songCount: 40, primaryMetric: 5414, secondaryMetric: 196 },
  { name: "Moyo Mtakatifu wa Yesu", icon: "favorite", songCount: 103, primaryMetric: 9418, secondaryMetric: 386 },
  { name: "Mwaka wa Kanisa", icon: "calendar_month", songCount: 263, primaryMetric: 25620, secondaryMetric: 836 },
  { name: "Mwanzo", icon: "flag", songCount: 257, primaryMetric: 79379, secondaryMetric: 2518 },
  { name: "Sadaka/Matoleo", icon: "volunteer_activism", songCount: 173, primaryMetric: 43378, secondaryMetric: 1284 },
  { name: "Shukurani", icon: "favorite", songCount: 303, primaryMetric: 32517, secondaryMetric: 1664 },
  { name: "Sifa", icon: "music_note", songCount: 31, primaryMetric: 4461, secondaryMetric: 205 },
  { name: "Zaburi", icon: "menu_book", songCount: 27, primaryMetric: 3154, secondaryMetric: 71 },
  { name: "Mama Maria", icon: "favorite", songCount: 35, primaryMetric: 3894, secondaryMetric: 156 },
  { name: "Miito", icon: "groups", songCount: 28, primaryMetric: 4022, secondaryMetric: 204 },
];

export const songs = [
  {
    id: 1,
    title: "Mungu ni Pendo",
    category: "Hymn",
    voices: "SATB",
    composer: "Emmanuel Mhando",
    rating: 4.9,
    reviews: 56,
  },
  {
    id: 2,
    title: "Misa ya Amani",
    category: "Mass Setting",
    voices: "SATB",
    composer: "Sr. Maria Mwesigawa",
    rating: 4.8,
    reviews: 32,
  },
  {
    id: 3,
    title: "Uneni Roho Mtakatifu",
    category: "Prayer Song",
    voices: "SATB",
    composer: "John B. Kamanzi",
    rating: 4.7,
    reviews: 28,
  },
];

export const statistics = [
  { value: "3,200+", label: "Song Works", icon: "music_note" },
  { value: "180+", label: "Contributors", icon: "groups" },
  { value: "850K+", label: "Total Downloads", icon: "download" },
  { value: "50+", label: "Countries", icon: "public" },
  { value: "—", label: "Music Engagement", icon: "star", detail: "Likes · Shares · Plays" },
];


/* Demo feed entries. Replace with recent-publications API data for live catalogue updates. */
export const recentPublishedSongs = [
  { id: 1, title: "Mungu ni Pendo", composer: "Emmanuel Mhando", category: "Hymn", publishedLabel: "Recently published" },
  { id: 2, title: "Misa ya Amani", composer: "Sr. Maria Mwesigawa", category: "Mass Setting", publishedLabel: "Recently published" },
  { id: 3, title: "Uneni Roho Mtakatifu", composer: "John B. Kamanzi", category: "Prayer Song", publishedLabel: "Recently published" },
];
