import { createFileRoute } from "@tanstack/react-router";

import calendar from "../data/liturgicalCalendar.json";
import LiturgicalCalendarPage from "../pages/public/LiturgicalCalendarPage.jsx";

const seasonIds = new Set(calendar.seasons.map((season) => season.id));
const cycles = new Set(["A", "B", "C"]);
const views = new Set(["grid", "list"]);

export const Route = createFileRoute("/liturgical-calendar")({
  validateSearch: (search) => {
    const read = (key) => (typeof search[key] === "string" && search[key] ? search[key] : "");
    const season = read("season");
    const cycle = read("cycle");
    const view = read("view");

    return {
      ...(seasonIds.has(season) ? { season } : {}),
      ...(cycles.has(cycle) && cycle !== "A" ? { cycle } : {}),
      ...(views.has(view) && view === "grid" ? { view } : {}),
      ...(read("q") ? { q: read("q") } : {}),
    };
  },
  component: LiturgicalCalendarPage,
});
