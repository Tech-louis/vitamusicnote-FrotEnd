import { Outlet, createFileRoute } from '@tanstack/react-router'

import VStudioLayout from '../../components/layout/VStudioLayout.jsx'
import { useApp } from '../../state/AppContext.jsx'
import '../../components/layout/VStudioLayout.css'

export const Route = createFileRoute('/vstudio')({ component: VStudioRoute })

function VStudioRoute() {
  const { user } = useApp()
  return <VStudioLayout user={user}><Outlet /></VStudioLayout>
}
