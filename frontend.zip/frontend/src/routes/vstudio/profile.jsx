import { createFileRoute } from '@tanstack/react-router'
import VStudioProfile from '../../pages/vstudio/VStudioProfile.jsx'

export const Route = createFileRoute('/vstudio/profile')({ component: IndexRoute })

function IndexRoute() {
  return <VStudioProfile />
}
