import { createFileRoute } from '@tanstack/react-router'
import VStudioSettings from '../../pages/vstudio/VStudioSettings.jsx'

export const Route = createFileRoute('/vstudio/settings')({ component: IndexRoute })

function IndexRoute() {
  return <VStudioSettings />
}
