import { createFileRoute } from '@tanstack/react-router'
import VStudioOverview from '../../pages/vstudio/VStudioOverview.jsx'

export const Route = createFileRoute('/vstudio/')({ component: IndexRoute })

function IndexRoute() {
  return <VStudioOverview />
}
