import { createFileRoute } from '@tanstack/react-router'
import InformationPage from '../pages/public/InformationPage.jsx'

export const Route = createFileRoute('/dmca')({ component: InfoRoute })

function InfoRoute() {
  return <InformationPage path="/dmca" />
}
