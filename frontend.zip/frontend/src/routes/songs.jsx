import { createFileRoute } from "@tanstack/react-router";
import SongsPage from "../pages/public/SongsPage.jsx";

export const Route = createFileRoute("/songs")({
  validateSearch: (search) => {
    const read = (key) => (typeof search[key] === "string" && search[key] ? search[key] : "");

    return {
      ...(read("q") ? { q: read("q") } : {}),
      ...(read("category") ? { category: read("category") } : {}),
      ...(read("composer") ? { composer: read("composer") } : {}),
      ...(read("voice") ? { voice: read("voice") } : {}),
      ...(read("sort") === "composer" ? { sort: "composer" } : {}),
    };
  },
  component: SongsPage,
});
