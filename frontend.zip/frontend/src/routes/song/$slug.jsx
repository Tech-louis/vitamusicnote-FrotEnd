import { createFileRoute } from '@tanstack/react-router'
import SongPage from '../../pages/public/SongPage.jsx'

export const Route = createFileRoute('/song/$slug')({
  component: SongRoute,
})

function SongRoute() {
  const { slug } = Route.useParams()
  return <SongPage slug={slug} />
}
