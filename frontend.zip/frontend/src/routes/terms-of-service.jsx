import { createFileRoute } from '@tanstack/react-router'
import InformationPage from '../pages/public/InformationPage.jsx'

export const Route = createFileRoute('/terms-of-service')({ component: InfoRoute })

function InfoRoute() {
  return <InformationPage path="/terms-of-service" />
}
