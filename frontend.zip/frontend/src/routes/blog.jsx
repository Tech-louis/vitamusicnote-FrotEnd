import { createFileRoute } from '@tanstack/react-router'
import BlogPage from '../pages/public/BlogPage.jsx'

export const Route = createFileRoute('/blog')({ component: BlogRoute })

function BlogRoute() {
  return <BlogPage />
}
