import { createFileRoute } from '@tanstack/react-router'
import ComposersPage from '../pages/public/ComposersPage.jsx'

export const Route = createFileRoute('/composers')({ component: ComposersRoute })

function ComposersRoute() {
  return <ComposersPage />
}
