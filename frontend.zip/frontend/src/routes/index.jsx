import { createFileRoute } from '@tanstack/react-router'
import HomePage from '../pages/public/HomePage.jsx'
import { useApp } from '../state/AppContext.jsx'

export const Route = createFileRoute('/')({ component: HomeRoute })

function HomeRoute() {
  const { appStarting } = useApp()
  return <HomePage loading={appStarting} />
}
