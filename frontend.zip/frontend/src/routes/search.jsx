import { createFileRoute } from '@tanstack/react-router'
import SearchPage from '../pages/public/SearchPage.jsx'

export const Route = createFileRoute('/search')({
  validateSearch: (search) => {
    const q = typeof search.q === 'string' ? search.q : ''
    return q ? { q } : {}
  },
  component: SearchRoute,
})

function SearchRoute() {
  return <SearchPage />
}
