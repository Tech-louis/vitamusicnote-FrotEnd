import { HeadContent, Outlet, Scripts, createRootRoute, useRouterState } from '@tanstack/react-router'

import appCss from '../styles/app.css?url'
import { LanguageProvider } from '../i18n/LanguageContext.jsx'
import { AppProvider } from '../state/AppContext.jsx'
import { NavOverlayProvider } from '../state/NavOverlayContext.jsx'
import PublicLayout from '../components/layout/PublicLayout.jsx'
import GlobalNavDrawer from '../components/layout/GlobalNavDrawer.jsx'

export const Route = createRootRoute({
  head: () => ({
    meta: [
      { charSet: 'utf-8' },
      { name: 'viewport', content: 'width=device-width, initial-scale=1' },
      { title: 'VitaMusicNote | Sacred Music Library' },
      {
        name: 'description',
        content: 'Discover, learn, share and access sacred and choral music through VitaMusicNote.',
      },
      { name: 'theme-color', content: '#08752d' },
    ],
    links: [
      { rel: 'stylesheet', href: appCss },
      { rel: 'icon', type: 'image/png', sizes: '32x32', href: '/images/icons/favicon.png' },
      { rel: 'icon', type: 'image/png', sizes: '48x48', href: '/images/icons/favicon-48.png' },
      { rel: 'apple-touch-icon', sizes: '180x180', href: '/images/icons/apple-touch-icon.png' },
    ],
  }),
  shellComponent: RootDocument,
  component: RootComponent,
})

function RootDocument({ children }) {
  return (
    <html lang="en">
      <head>
        <HeadContent />
      </head>
      <body>
        <div id="root">{children}</div>
        <Scripts />
      </body>
    </html>
  )
}

function RootComponent() {
  const pathname = useRouterState({ select: (state) => state.location.pathname })
  const isStudio = pathname === '/vstudio' || pathname.startsWith('/vstudio/')

  return (
    <LanguageProvider>
      <AppProvider>
        <NavOverlayProvider>
          {isStudio ? (
            <>
              <a className="skip-link" href="#main-content">Skip to main content</a>
              <Outlet />
            </>
          ) : (
            <PublicLayout>
              <a className="skip-link" href="#main-content">Skip to main content</a>
              <main id="main-content" tabIndex="-1">
                <Outlet />
              </main>
            </PublicLayout>
          )}
          <GlobalNavDrawer />
        </NavOverlayProvider>
      </AppProvider>
    </LanguageProvider>
  )
}
