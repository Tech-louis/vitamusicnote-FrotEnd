import { composers } from "../data/composers.js";
import { songs } from "../data/music.js";

/**
 * Single source of truth for catalogue search.
 *
 * The header and the search page used to duplicate their filtering logic, which
 * meant the same query could return different results in different places.
 */
export function normalizeQuery(value) {
  return String(value ?? "").trim().replace(/\s+/g, " ");
}

function includesNeedle(fields, needle) {
  return fields.some((field) =>
    String(field ?? "").toLocaleLowerCase().includes(needle)
  );
}

export function songMatchesQuery(song, query) {
  const needle = normalizeQuery(query).toLocaleLowerCase();
  if (!needle) return false;
  return includesNeedle(
    [song.title, song.composer, song.category, song.voices, song.description],
    needle
  );
}

export function composerMatchesQuery(composer, query) {
  const normalized = normalizeQuery(query).toLocaleLowerCase();
  if (!normalized) return true;

  const fields = [
    composer.name,
    composer.location,
    composer.focus,
    composer.bio,
    ...(composer.works || []).flatMap((work) =>
      [work.title, work.category, work.voices, work.description]
    ),
  ];
  const searchable = fields
    .map((field) => String(field ?? "").toLocaleLowerCase())
    .join(" ");
  const terms = normalized.split(/\s+/).filter(Boolean);

  return terms.every((term) => searchable.includes(term));
}

/**
 * @returns {{ query: string, songs: Array, composers: Array }}
 */
export function searchCatalog(query, options = {}) {
  const normalized = normalizeQuery(query);
  const { songLimit = Infinity, composerLimit = Infinity } = options;
  if (!normalized) return { query: "", songs: [], composers: [] };

  return {
    query: normalized,
    songs: songs.filter((song) => songMatchesQuery(song, normalized)).slice(0, songLimit),
    composers: composers
      .filter((composer) => composerMatchesQuery(composer, normalized))
      .slice(0, composerLimit),
  };
}

/**
 * Flattened results used by the header search dialog.
 */
export function searchSuggestions(query, options = {}) {
  const { songLimit = 5, composerLimit = 3 } = options;
  const results = searchCatalog(query, { songLimit, composerLimit });

  return [
    ...results.songs.map((song) => ({
      id: `song-${song.id}`,
      kind: "song",
      label: song.title,
      meta: `${song.composer} · ${song.category}`,
      query: song.title,
    })),
    ...results.composers.map((composer) => ({
      id: `composer-${composer.id}`,
      kind: "composer",
      label: composer.name,
      meta: `${composer.workCount} works · ${composer.location}`,
      query: composer.name,
    })),
  ];
}
