/**
 * Resolve an audio preview URL from the common API field names.
 * Kept separate from components so both cards and list rows can share it.
 */
export function getPreviewUrl(song) {
  const candidates = [
    song?.preview_url,
    song?.audio_preview_url,
    song?.audio_url,
    song?.audio_file,
    song?.preview,
    song?.file_url,
    song?.file,
    song?.audio?.preview_url,
    song?.audio?.url,
    song?.media?.audio_url,
    song?.media?.url,
  ];
  const value = candidates.find((item) => typeof item === "string" && item.trim());
  return value || "";
}
