/* Local library storage for favorites and playlists.
   Replace these helpers with API calls when the library service is connected. */
const FAVORITES_KEY = "vitamusicnote-favorites";
const PLAYLISTS_KEY = "vitamusicnote-playlists";
const CHANGE_EVENT = "vitamusicnote-library-change";

function read(key, fallback) {
  try {
    const parsed = JSON.parse(localStorage.getItem(key) || "null");
    return Array.isArray(parsed) ? parsed : fallback;
  } catch {
    return fallback;
  }
}

function write(key, value) {
  try {
    localStorage.setItem(key, JSON.stringify(value));
  } catch {
    /* storage may be unavailable */
  }
  window.dispatchEvent(new CustomEvent(CHANGE_EVENT));
}

export const libraryService = {
  getFavoriteIds() {
    return read(FAVORITES_KEY, []).filter((id) => Number.isFinite(id));
  },

  isFavorite(id) {
    return this.getFavoriteIds().includes(id);
  },

  toggleFavorite(id) {
    if (!Number.isFinite(id)) return;
    const current = this.getFavoriteIds();
    write(FAVORITES_KEY, current.includes(id) ? current.filter((item) => item !== id) : [...current, id]);
  },

  getPlaylists() {
    return read(PLAYLISTS_KEY, []).filter((item) => item && typeof item.name === "string");
  },

  createPlaylist(name) {
    const trimmed = name.trim();
    if (!trimmed) return;
    const playlists = this.getPlaylists();
    write(PLAYLISTS_KEY, [
      ...playlists,
      { id: `${Date.now()}`, name: trimmed, songIds: [], createdAt: new Date().toISOString() },
    ]);
  },

  togglePlaylistSong(playlistId, songId) {
    const playlists = this.getPlaylists().map((playlist) => {
      if (playlist.id !== playlistId) return playlist;
      const songIds = Array.isArray(playlist.songIds) ? playlist.songIds : [];
      return {
        ...playlist,
        songIds: songIds.includes(songId)
          ? songIds.filter((id) => id !== songId)
          : [...songIds, songId],
      };
    });
    write(PLAYLISTS_KEY, playlists);
  },

  deletePlaylist(playlistId) {
    write(PLAYLISTS_KEY, this.getPlaylists().filter((playlist) => playlist.id !== playlistId));
  },

  subscribe(callback) {
    window.addEventListener(CHANGE_EVENT, callback);
    return () => window.removeEventListener(CHANGE_EVENT, callback);
  },
};

export default libraryService;
