const configuredBase = (import.meta.env.VITE_API_BASE_URL || "").trim().replace(/\/+$/, "");

export function hasApiBase() {
  return Boolean(configuredBase);
}

export function apiUrl(path = "") {
  const normalizedPath = path.startsWith("/") ? path : `/${path}`;
  return `${configuredBase}${normalizedPath}`;
}

function getCookie(name) {
  const prefix = `${name}=`;
  const item = document.cookie
    .split(";")
    .map((cookie) => cookie.trim())
    .find((cookie) => cookie.startsWith(prefix));
  return item ? decodeURIComponent(item.slice(prefix.length)) : "";
}

async function ensureCsrfCookie() {
  if (getCookie("csrftoken")) return getCookie("csrftoken");

  // Django commonly sets the CSRF cookie while serving its root page.
  // This bootstrap request is only needed when the cookie is not already present.
  try {
    await fetch(apiUrl("/"), { method: "GET", credentials: "include" });
  } catch {
    // The actual API request will report the connection error.
  }
  return getCookie("csrftoken");
}

function extractErrorMessage(data) {
  if (!data || typeof data !== "object") return "";
  const primary = data.error || data.detail || data.message;
  if (primary) return String(primary);

  if (data.errors && typeof data.errors === "object") {
    return Object.values(data.errors).flat().map(String).join(" ");
  }

  return Object.entries(data)
    .map(([key, value]) => `${key}: ${Array.isArray(value) ? value.join(" ") : value}`)
    .join(" ");
}

export async function apiRequest(path, options = {}) {
  const method = (options.method || "GET").toUpperCase();
  const headers = new Headers(options.headers || {});
  const isFormData = options.body instanceof FormData;

  if (options.body != null && !isFormData && !headers.has("Content-Type")) {
    headers.set("Content-Type", "application/json");
  }

  if (!["GET", "HEAD", "OPTIONS"].includes(method)) {
    const csrfToken = await ensureCsrfCookie();
    if (csrfToken) headers.set("X-CSRFToken", csrfToken);
  }

  let body = options.body;
  if (body != null && !isFormData && typeof body !== "string") {
    body = JSON.stringify(body);
  }

  let response;
  try {
    response = await fetch(apiUrl(path), {
      ...options,
      method,
      headers,
      body,
      credentials: options.credentials || "include",
    });
  } catch {
    throw new Error("Unable to connect to VitaMusicNote server. Check the API URL and your connection.");
  }

  const contentType = response.headers.get("content-type") || "";
  const data = contentType.includes("application/json")
    ? await response.json().catch(() => ({}))
    : await response.text().catch(() => "");

  if (!response.ok) {
    const message = extractErrorMessage(data);
    throw new Error(message || `Request failed (${response.status}).`);
  }

  return data;
}

export default apiRequest;
