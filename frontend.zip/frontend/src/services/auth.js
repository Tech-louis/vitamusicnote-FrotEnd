import apiRequest from "./api.js";

export const authService = {
  login(credentials) {
    return apiRequest("/api/login/", {
      method: "POST",
      body: credentials,
    });
  },

  register(details) {
    return apiRequest("/api/register/", {
      method: "POST",
      body: details,
    });
  },

  checkLoginStatus() {
    return apiRequest("/api/check-login-status/");
  },

  logout() {
    return apiRequest("/api/session/logout/", {
      method: "POST",
      body: {},
    });
  },

  getProfile() {
    return apiRequest("/api/profile/");
  },
};

export default authService;
