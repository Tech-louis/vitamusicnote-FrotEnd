import { createContext, useCallback, useContext, useMemo, useState } from "react";

const NavOverlayContext = createContext(null);

export function NavOverlayProvider({ children }) {
  const [drawerOpen, setDrawerOpen] = useState(false);

  const openDrawer = useCallback(() => setDrawerOpen(true), []);
  const closeDrawer = useCallback(() => setDrawerOpen(false), []);
  const toggleDrawer = useCallback(() => setDrawerOpen((open) => !open), []);

  const value = useMemo(
    () => ({ drawerOpen, openDrawer, closeDrawer, toggleDrawer }),
    [drawerOpen, openDrawer, closeDrawer, toggleDrawer],
  );

  return <NavOverlayContext.Provider value={value}>{children}</NavOverlayContext.Provider>;
}

export function useNavOverlay() {
  const context = useContext(NavOverlayContext);
  if (!context) throw new Error("useNavOverlay must be used inside NavOverlayProvider");
  return context;
}
