import {
  createContext,
  useCallback,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react'
import { useNavigate } from '@tanstack/react-router'

import Modal from '../components/common/Modal.jsx'
import Login from '../pages/auth/Login.jsx'
import Register from '../pages/auth/Register.jsx'
import { GlobalProgressBar, SplashScreen } from '../components/common/LoadingExperience.jsx'
import { authService } from '../services/auth.js'
import { apiUrl, hasApiBase } from '../services/api.js'
import { useTranslation } from '../i18n/useTranslation.js'

const AppContext = createContext(null)
const isBrowser = typeof window !== 'undefined'
const GOOGLE_AUTH_PARAM = 'google_auth'
const GOOGLE_ERROR_PARAM = 'google_error'

function googleReturnPath() {
  if (!isBrowser) return '/'
  const url = new URL(window.location.href)
  const names = [GOOGLE_AUTH_PARAM, GOOGLE_ERROR_PARAM, 'error', 'error_description']
  names.forEach((name) => url.searchParams.delete(name))
  url.hash = ''
  return `${url.pathname}${url.search}`
}

function clearGoogleAuthParams() {
  if (!isBrowser) return
  const url = new URL(window.location.href)
  const names = [GOOGLE_AUTH_PARAM, GOOGLE_ERROR_PARAM, 'error', 'error_description']
  if (!names.some((name) => url.searchParams.has(name))) return
  names.forEach((name) => url.searchParams.delete(name))
  window.history.replaceState(null, '', `${url.pathname}${url.search}${url.hash}`)
}

function readStorage(key, fallback) {
  if (!isBrowser) return fallback
  try {
    const value = window.localStorage.getItem(key)
    return value === null ? fallback : value
  } catch {
    return fallback
  }
}

export function AppProvider({ children }) {
  const { t } = useTranslation()
  const navigate = useNavigate()

  const [loginOpen, setLoginOpen] = useState(false)
  const [loginError, setLoginError] = useState('')
  const [authMode, setAuthMode] = useState('login')
  const [authLoading, setAuthLoading] = useState(false)
  const [appStarting, setAppStarting] = useState(true)
  const [theme, setTheme] = useState(() => readStorage('vitamusicnote-theme', 'light'))
  const [fontScale, setFontScale] = useState(() => Number(readStorage('vitamusicnote-font-scale', '1')) || 1)
  const [highContrast, setHighContrast] = useState(() => readStorage('vitamusicnote-high-contrast', 'false') === 'true')
  const [user, setUser] = useState(null)
  const [isAuthenticated, setIsAuthenticated] = useState(false)
  const [authChecking, setAuthChecking] = useState(true)

  useEffect(() => {
    const timer = window.setTimeout(() => setAppStarting(false), 700)
    return () => window.clearTimeout(timer)
  }, [])

  useEffect(() => {
    document.documentElement.dataset.theme = theme
    try { window.localStorage.setItem('vitamusicnote-theme', theme) } catch { /* storage may be unavailable */ }
  }, [theme])

  useEffect(() => {
    document.documentElement.style.setProperty('--font-scale', String(fontScale))
    try { window.localStorage.setItem('vitamusicnote-font-scale', String(fontScale)) } catch { /* storage may be unavailable */ }
  }, [fontScale])

  useEffect(() => {
    document.documentElement.classList.toggle('high-contrast', highContrast)
    try { window.localStorage.setItem('vitamusicnote-high-contrast', String(highContrast)) } catch { /* storage may be unavailable */ }
  }, [highContrast])

  useEffect(() => {
    let isMounted = true
    const params = isBrowser ? new URLSearchParams(window.location.search) : null
    const googleStatus = params?.get(GOOGLE_AUTH_PARAM) || ''
    const googleError = params?.get(GOOGLE_ERROR_PARAM)
      || params?.get('error_description')
      || params?.get('error')
      || ''

    async function restoreSession() {
      try {
        if (googleStatus === 'error') {
          setLoginError(googleError || t('googleLoginFailed'))
          setAuthMode('login')
          setLoginOpen(true)
        }

        const data = await authService.checkLoginStatus()
        if (!isMounted) return
        if (data.logged_in) {
          setUser(data.user_data)
          setIsAuthenticated(true)
          if (googleStatus === 'success') {
            setLoginOpen(false)
            setAuthMode('login')
          }
        } else {
          setUser(null)
          setIsAuthenticated(false)
          if (googleStatus === 'success') {
            setLoginError(t('googleLoginFailed'))
            setAuthMode('login')
            setLoginOpen(true)
          }
        }
      } catch (error) {
        console.error('Session restoration failed:', error)
        if (isMounted) {
          setUser(null)
          setIsAuthenticated(false)
          if (googleStatus === 'success') {
            setLoginError(t('googleLoginFailed'))
            setAuthMode('login')
            setLoginOpen(true)
          }
        }
      } finally {
        if (isMounted) {
          setAuthChecking(false)
          if (googleStatus) clearGoogleAuthParams()
        }
      }
    }

    restoreSession()
    return () => { isMounted = false }
  }, [t])

  const openLogin = useCallback(() => {
    setLoginError('')
    setAuthMode('login')
    setLoginOpen(true)
  }, [])

  const openRegister = useCallback(() => {
    setLoginError('')
    setAuthMode('register')
    setLoginOpen(true)
  }, [])

  const closeAuth = useCallback(() => {
    setLoginOpen(false)
    setLoginError('')
    setAuthLoading(false)
  }, [])

  const switchAuthMode = useCallback((mode) => {
    setLoginError('')
    setAuthMode(mode)
  }, [])

  const googleAuthUrl = useCallback((process) => {
    if (!hasApiBase()) return ''
    const params = new URLSearchParams()
    if (process === 'signup') params.set('process', 'signup')

    const returnUrl = new URL(googleReturnPath(), isBrowser ? window.location.origin : 'http://localhost')
    returnUrl.searchParams.set(GOOGLE_AUTH_PARAM, 'success')
    params.set('next', `${returnUrl.pathname}${returnUrl.search}`)

    return `${apiUrl('/accounts/google/login/')}?${params.toString()}`
  }, [])

  const handleGoogleUnavailable = useCallback(() => {
    setAuthMode('login')
    setLoginOpen(true)
    setLoginError(t('googleLoginUnavailable'))
  }, [t])

  const handleLogin = useCallback(async (credentials) => {
    setLoginError('')
    setAuthLoading(true)
    try {
      const data = await authService.login(credentials)
      if (data.success === false) throw new Error(data.error || data.detail || t('loginFailed'))
      const session = await authService.checkLoginStatus()
      if (session.logged_in) {
        setUser(session.user_data)
        setIsAuthenticated(true)
      }
      setLoginOpen(false)
      setLoginError('')
    } catch (error) {
      setLoginError(error.message || t('loginFailed'))
    } finally {
      setAuthLoading(false)
    }
  }, [t])

  const handleRegister = useCallback(async (details) => {
    setLoginError('')
    if (details.password !== details.password_confirmation) {
      setLoginError(t('passwordMismatch'))
      return
    }
    if (!details.privacy_policy) {
      setLoginError(t('acceptPolicyRequired'))
      return
    }
    setAuthLoading(true)
    try {
      const payload = { ...details }
      delete payload.privacy_policy
      const data = await authService.register(payload)
      if (data.success === false) throw new Error(data.message || data.error || t('registrationFailed'))
      setAuthMode('login')
      setLoginError('')
      window.alert(t('registrationSuccess'))
    } catch (error) {
      setLoginError(error.message || t('registrationFailed'))
    } finally {
      setAuthLoading(false)
    }
  }, [t])

  const handleLogout = useCallback(async () => {
    setAuthLoading(true)
    try {
      await authService.logout()
      setUser(null)
      setIsAuthenticated(false)
    } catch (error) {
      console.error('Logout error:', error)
    } finally {
      setAuthLoading(false)
    }
  }, [])

  const updateUser = useCallback((changes) => {
    setUser((current) => (current ? { ...current, ...changes } : current))
  }, [])

  const runSearch = useCallback((query) => {
    const trimmed = (query || '').trim()
    navigate({
      to: '/songs',
      search: trimmed ? { q: trimmed } : {},
    })
  }, [navigate])

  const value = useMemo(() => ({
    theme,
    setTheme,
    fontScale,
    setFontScale,
    highContrast,
    setHighContrast,
    user,
    isAuthenticated,
    authChecking,
    authLoading,
    loginOpen,
    loginError,
    authMode,
    openLogin,
    openRegister,
    closeAuth,
    switchAuthMode,
    handleLogin,
    handleRegister,
    handleLogout,
    updateUser,
    appStarting,
    notifications: [],
    runSearch,
  }), [
    theme, fontScale, highContrast, user, isAuthenticated, authChecking,
    authLoading, loginOpen, loginError, authMode, openLogin, openRegister,
    closeAuth, switchAuthMode, handleLogin, handleRegister, handleLogout,
    updateUser, appStarting, runSearch,
  ])

  return (
    <AppContext.Provider value={value}>
      <GlobalProgressBar active={authLoading} />
      <SplashScreen visible={appStarting} theme={theme} />
      {children}
      <Modal
        open={loginOpen}
        title={authMode === 'login' ? t('loginTitle') : t('registerTitle')}
        onClose={closeAuth}
      >
        {authMode === 'login' ? (
          <Login
            loading={authLoading}
            error={loginError}
            onLogin={handleLogin}
            onGoogleLogin={googleAuthUrl('login')}
            onGoogleError={handleGoogleUnavailable}
            onForgotPassword={() => setLoginError(t('forgotPasswordPending'))}
            onHome={closeAuth}
            onCreateAccount={() => switchAuthMode('register')}
          />
        ) : (
          <Register
            loading={authLoading}
            error={loginError}
            onRegister={handleRegister}
            onGoogleSignup={googleAuthUrl('signup')}
            onGoogleError={handleGoogleUnavailable}
            onLogin={() => switchAuthMode('login')}
            onHome={closeAuth}
          />
        )}
      </Modal>
    </AppContext.Provider>
  )
}

export function useApp() {
  const context = useContext(AppContext)
  if (!context) throw new Error('useApp must be used inside <AppProvider>')
  return context
}

export default AppContext
