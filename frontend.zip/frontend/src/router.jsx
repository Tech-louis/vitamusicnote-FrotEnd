import { createRouter } from '@tanstack/react-router'
import { routeTree } from './routeTree.gen'
import NotFoundPage from './pages/public/NotFoundPage.jsx'

export function getRouter() {
  return createRouter({
    routeTree,
    defaultPreload: 'intent',
    defaultNotFoundComponent: NotFoundPage,
    scrollRestoration: true,
  })
}
